import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'form_copy_model.dart';
export 'form_copy_model.dart';

class FormCopyWidget extends StatefulWidget {
  const FormCopyWidget({
    Key? key,
    required this.userref,
  }) : super(key: key);

  final DocumentReference? userref;

  @override
  _FormCopyWidgetState createState() => _FormCopyWidgetState();
}

class _FormCopyWidgetState extends State<FormCopyWidget> {
  late FormCopyModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => FormCopyModel());

    _model.sKUNameController ??= TextEditingController();
    _model.lenController ??= TextEditingController();
    _model.widthController ??= TextEditingController();
    _model.heightController ??= TextEditingController();
    _model.quantityController ??= TextEditingController();
    _model.costController ??= TextEditingController();
    _model.commentsController ??= TextEditingController();
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () => FocusScope.of(context).requestFocus(_model.unfocusNode),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: FlutterFlowTheme.of(context).primary,
          automaticallyImplyLeading: false,
          leading: FlutterFlowIconButton(
            borderColor: FlutterFlowTheme.of(context).primary,
            borderRadius: 20.0,
            borderWidth: 1.0,
            buttonSize: 40.0,
            fillColor: FlutterFlowTheme.of(context).accent1,
            icon: Icon(
              Icons.arrow_back,
              color: Colors.black,
              size: 24.0,
            ),
            onPressed: () async {
              context.pushNamed('UserHome');
            },
          ),
          title: Text(
            'Form',
            style: FlutterFlowTheme.of(context).headlineMedium.override(
                  fontFamily: 'Outfit',
                  color: Colors.white,
                  fontSize: 22.0,
                ),
          ),
          actions: [],
          centerTitle: false,
          elevation: 2.0,
        ),
        body: SafeArea(
          top: true,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 8.0, 0.0),
                  child: TextFormField(
                    controller: _model.sKUNameController,
                    autofocus: true,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'SKU Name',
                      labelStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Readex Pro',
                                color: Colors.black,
                              ),
                      hintText: 'Enter SKU Name',
                      hintStyle: FlutterFlowTheme.of(context).bodySmall,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 0.0, 24.0),
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                        ),
                    validator:
                        _model.sKUNameControllerValidator.asValidator(context),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 16.0, 8.0, 0.0),
                  child: Container(
                    width: 390.0,
                    height: 80.0,
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 0.0, 0.0, 0.0),
                          child: Text(
                            'Vendor :',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.black,
                                ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 0.0, 0.0, 0.0),
                          child: AuthUserStreamWidget(
                            builder: (context) => Text(
                              valueOrDefault(currentUserDocument?.vendor, ''),
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                  ),
                            ),
                          ),
                        ),
                      ].divide(SizedBox(height: 20.0)),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 8.0, 8.0),
                  child: Container(
                    width: 390.0,
                    height: 80.0,
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 0.0, 0.0, 0.0),
                          child: Text(
                            'Select Category :',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.black,
                                ),
                          ),
                        ),
                        StreamBuilder<List<CategoriesRecord>>(
                          stream: queryCategoriesRecord(),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 50.0,
                                  height: 50.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).primary,
                                    ),
                                  ),
                                ),
                              );
                            }
                            List<CategoriesRecord>
                                dropDownCategoriesRecordList = snapshot.data!;
                            return FlutterFlowDropDown<String>(
                              controller: _model.dropDownValueController1 ??=
                                  FormFieldController<String>(null),
                              options: dropDownCategoriesRecordList
                                  .map((e) => e.name)
                                  .toList(),
                              onChanged: (val) =>
                                  setState(() => _model.dropDownValue1 = val),
                              width: 300.0,
                              height: 50.0,
                              textStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                  ),
                              hintText: 'Please select...',
                              icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                size: 24.0,
                              ),
                              fillColor: Colors.white,
                              elevation: 2.0,
                              borderColor:
                                  FlutterFlowTheme.of(context).alternate,
                              borderWidth: 2.0,
                              borderRadius: 8.0,
                              margin: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 4.0, 16.0, 4.0),
                              hidesUnderline: true,
                              isSearchable: false,
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 8.0, 8.0, 8.0),
                  child: Container(
                    width: 390.0,
                    height: 80.0,
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.max,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(
                              8.0, 0.0, 0.0, 0.0),
                          child: Text(
                            'Select Sub-Category :',
                            style: FlutterFlowTheme.of(context)
                                .bodyMedium
                                .override(
                                  fontFamily: 'Readex Pro',
                                  color: Colors.black,
                                ),
                          ),
                        ),
                        StreamBuilder<List<SubcategoriesRecord>>(
                          stream: querySubcategoriesRecord(),
                          builder: (context, snapshot) {
                            // Customize what your widget looks like when it's loading.
                            if (!snapshot.hasData) {
                              return Center(
                                child: SizedBox(
                                  width: 50.0,
                                  height: 50.0,
                                  child: CircularProgressIndicator(
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      FlutterFlowTheme.of(context).primary,
                                    ),
                                  ),
                                ),
                              );
                            }
                            List<SubcategoriesRecord>
                                dropDownSubcategoriesRecordList =
                                snapshot.data!;
                            return FlutterFlowDropDown<String>(
                              controller: _model.dropDownValueController2 ??=
                                  FormFieldController<String>(null),
                              options: dropDownSubcategoriesRecordList
                                  .map((e) => e.name)
                                  .toList(),
                              onChanged: (val) =>
                                  setState(() => _model.dropDownValue2 = val),
                              width: 300.0,
                              height: 50.0,
                              textStyle: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.black,
                                  ),
                              hintText: 'Please select...',
                              icon: Icon(
                                Icons.keyboard_arrow_down_rounded,
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                size: 24.0,
                              ),
                              fillColor: Colors.white,
                              elevation: 2.0,
                              borderColor:
                                  FlutterFlowTheme.of(context).alternate,
                              borderWidth: 2.0,
                              borderRadius: 8.0,
                              margin: EdgeInsetsDirectional.fromSTEB(
                                  16.0, 4.0, 16.0, 4.0),
                              hidesUnderline: true,
                              isSearchable: false,
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 16.0),
                  child: TextFormField(
                    controller: _model.lenController,
                    autofocus: true,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Length',
                      labelStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Readex Pro',
                                color: Colors.black,
                              ),
                      hintText: 'Enter Length in cm',
                      hintStyle: FlutterFlowTheme.of(context).bodySmall,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 0.0, 24.0),
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                        ),
                    validator:
                        _model.lenControllerValidator.asValidator(context),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp('[0-9]'))
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 16.0),
                  child: TextFormField(
                    controller: _model.widthController,
                    autofocus: true,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Width',
                      labelStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Readex Pro',
                                color: Colors.black,
                              ),
                      hintText: 'Enter Width in cm',
                      hintStyle: FlutterFlowTheme.of(context).bodySmall,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 0.0, 24.0),
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                        ),
                    validator:
                        _model.widthControllerValidator.asValidator(context),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp('[0-9]'))
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 16.0),
                  child: TextFormField(
                    controller: _model.heightController,
                    autofocus: true,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Height',
                      labelStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Readex Pro',
                                color: Colors.black,
                              ),
                      hintText: 'Enter Height in cm',
                      hintStyle: FlutterFlowTheme.of(context).bodySmall,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 0.0, 24.0),
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                        ),
                    validator:
                        _model.heightControllerValidator.asValidator(context),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp('[0-9]'))
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 16.0),
                  child: TextFormField(
                    controller: _model.quantityController,
                    autofocus: true,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Quantity',
                      labelStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Readex Pro',
                                color: Colors.black,
                              ),
                      hintText: 'Enter Quantity',
                      hintStyle: FlutterFlowTheme.of(context).bodySmall,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 0.0, 24.0),
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                        ),
                    validator:
                        _model.quantityControllerValidator.asValidator(context),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp('[0-9]'))
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 16.0),
                  child: TextFormField(
                    controller: _model.costController,
                    autofocus: true,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Cost',
                      labelStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Readex Pro',
                                color: Colors.black,
                              ),
                      hintText: 'Enter Cost',
                      hintStyle: FlutterFlowTheme.of(context).bodySmall,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 0.0, 24.0),
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                        ),
                    validator:
                        _model.costControllerValidator.asValidator(context),
                    inputFormatters: [
                      FilteringTextInputFormatter.allow(RegExp('[0-9]'))
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(8.0, 0.0, 8.0, 16.0),
                  child: TextFormField(
                    controller: _model.commentsController,
                    autofocus: true,
                    obscureText: false,
                    decoration: InputDecoration(
                      labelText: 'Comment',
                      labelStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Readex Pro',
                                color: Colors.black,
                              ),
                      hintText: 'Add Comment',
                      hintStyle: FlutterFlowTheme.of(context).bodySmall,
                      enabledBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Colors.black,
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      errorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                        borderSide: BorderSide(
                          color: Color(0x00000000),
                          width: 2.0,
                        ),
                        borderRadius: BorderRadius.circular(8.0),
                      ),
                      contentPadding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 24.0, 0.0, 24.0),
                    ),
                    style: FlutterFlowTheme.of(context).bodyMedium.override(
                          fontFamily: 'Readex Pro',
                          color: Colors.black,
                        ),
                    validator:
                        _model.commentsControllerValidator.asValidator(context),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Text(
                      'Upload Images',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Readex Pro',
                            color: Colors.black,
                            fontSize: 16.0,
                          ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                50.0, 0.0, 0.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                final selectedMedia =
                                    await selectMediaWithSourceBottomSheet(
                                  context: context,
                                  allowPhoto: true,
                                );
                                if (selectedMedia != null &&
                                    selectedMedia.every((m) =>
                                        validateFileFormat(
                                            m.storagePath, context))) {
                                  setState(
                                      () => _model.isDataUploading1 = true);
                                  var selectedUploadedFiles =
                                      <FFUploadedFile>[];

                                  var downloadUrls = <String>[];
                                  try {
                                    selectedUploadedFiles = selectedMedia
                                        .map((m) => FFUploadedFile(
                                              name:
                                                  m.storagePath.split('/').last,
                                              bytes: m.bytes,
                                              height: m.dimensions?.height,
                                              width: m.dimensions?.width,
                                              blurHash: m.blurHash,
                                            ))
                                        .toList();

                                    downloadUrls = (await Future.wait(
                                      selectedMedia.map(
                                        (m) async => await uploadData(
                                            m.storagePath, m.bytes),
                                      ),
                                    ))
                                        .where((u) => u != null)
                                        .map((u) => u!)
                                        .toList();
                                  } finally {
                                    _model.isDataUploading1 = false;
                                  }
                                  if (selectedUploadedFiles.length ==
                                          selectedMedia.length &&
                                      downloadUrls.length ==
                                          selectedMedia.length) {
                                    setState(() {
                                      _model.uploadedLocalFile1 =
                                          selectedUploadedFiles.first;
                                      _model.uploadedFileUrl1 =
                                          downloadUrls.first;
                                    });
                                  } else {
                                    setState(() {});
                                    return;
                                  }
                                }
                              },
                              child: Container(
                                width: 100.0,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: Image.network(
                                      valueOrDefault<String>(
                                        _model.uploadedFileUrl1,
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX////t7e319fXu7u729vbs7OwAAADr6+vp6enx8fH6+voTExMQEBB5eXn7+/s9PT3Q0NDDw8Pd3d0wMDCGhoa8vLybm5tiYmI4ODhdXV0eHh4mJiYhISF+fn6ioqKLi4tsbGzNzc2zs7MsLCxERESoqKi0tLSWlpbAwMDY2NhTU1NpaWne8zMCAAANN0lEQVR4nO2dC3uUPBOGIQnQsAdb9Wst3dqtrfqq////fWEhQMhpctx2lUt7TZdDeAqbOzOZJAXGuCQF26oLNYp/Ct+9UZRsO1kNM9AFGgUhBKHxBxp+XJQxPEfC9Da9gS7PKIvBwrgapF6cgf8WhU1TDY+1qaqryzKqgv1vTnXO1YUaAg/xG8BXQuI3b+OG0hB/RCTGbwDQiYg/4BGRd45+hORdw3OcEBkd/QRn5TsupV0D8SeAIBybSJTmpB8tpV34ohSqyuLEnxAZGf2koRn5jqtS2qUifhOLuexrkY/vzWhgbCJ+XANjSjPSbygL04w+PissYyOJDjA3E382cAyvv6/asvGdPbpWvWtB/IURjH4yXCObI88aK23/w0r8WKQm1VhxZwI9Hu6Zan38JPDFqa68NjDmCvUe8Pk98ele3c9Ck0Kjjy/T0xf941uaz5EnuDLdqtHH90N/Uzbp+c4N9iBG5xbm48cx6NiUyYDBhsclGgn0CYnf6OGbE/QW4gein8ZoMIAaFdRelpr4C/S7wJcMG3I7K8A4/WuR6Rgd8f3Qn7t3YKAFa/5ao/rxgFZmpejwZzU72ZGJT2m2pgxivtkQs6DGg/XE9wI9+3pnBP34lpYRovoQ9FesEUQsx8Q0RiQ4RvXDPPqs8Ww8tS5sB79XhXDDQnwQ+sU/ZzSsY+2uilJ4o8JCfIjXP22ZPHp+N0D3/6QyMD5PJvjm8egHSGAj6OMTP5tHXxo9+lTEN3vZ0Y3pGcIVOmFdsYtd54302l9MP365Dt3nIH5mA+5kv1eF8EAJlPjv14ASXxO6z+HIh5UFJ76KuV6xdy/QT56nZ+aeK5FGN5cV2sDPIlffH4+PPyjKi1wf4jPnevLo4WeR7/Vp2/5oPRU6/DUDffwSz6AHR/6Lp5pvX1svdjeZiY9Lp7PI53revjp2E0xd89zx9c/cczAodYmCt0uBdX3bupRVTmVRn8QAT4XYRWHVPtXi9rX1KstPoR/xSxePnnyu19ttCz+dPcOhjYZdXPsQ4pPlBnDJC1kgk1iAIS6Wl4P4mE48pPazsPSKDtv3wo34OB/xUTkrBESmW9UT5NVNhmi6B/HR3KYBHKwVeJKYTaEjRhsew3cCvbw5oJ+4tC5y+viKWlSQmD1XP64hgV79XUwe807o42tqUfFFTa8QSnw9anUBf8sryp+i9so4zrBBcFTfFEVX7VKDXiFRg34/vgdF9RkkdKF7hbOvA728qdGP/fgeQnzUJ8TCD7ZWMssXNWU3AYj4vN3koNBBoAb9wzM0hO6jR/UJe3MMzBV3GUEvb2v0szsbO7NyRfWrEldWT7xpoKBXSBQuyJPx3MIIQcRvWKMwJujlTUB/3Ax/kELM08e8Qf/F8NvwFGf0lxQcsY9GfPYVhDjXw3NWvaK7Z+HXqzvVU+ShClBZ1r5+OPGdnGuiBv2u+E/4/VfxRyGx4Ln24D76KMQn1ImwStAfi+JG+OC6KO7lw3r0j9U1e8Ni9f5biY9cBp+hcq94gkygrFAlkVU3DkH0aMTHLqF7VS26I0qFyhd17xO6N6MfQny30P12/QRJo1a4V72orbsjbwk1WHL1G6coOv3R36Uo8XjaRf8nfPixOqXerSRuXur6Od7YQAjxXQef0UO9lrgbdq0VjoUK0Ni8bB7qDwXN6eOXgMy/hUE59GaJx8KocPkUty/bunuYd+UhvtvwOnRbryQei5HdkkJ+1iyx6/of9Q8a5tHDiU9aJJLcbux/1qLEXTFdbEX8luN4/0dQuNl+b/34jnS7dMQnFdV69FrjWy1IPC52KerScdfwFDfb+mWz7Q71f66FehOfegyvu6qXEo/LXQqFfNd9X8kcHg7b/n935VqoN/GxUxbCaBwXKnYEqJDVqKySqQ8P/Z5H4lyot49feiTjlbOIIxLYrXpL+Vkj+g+MNV3IbABq9CuJ7+1ct/hh1PC5ODUY+C4V8aezSLEbP/9C8kT1ccjgs+8f2JO4u+afjNfR8ZB79Nf3Xb19/eZbqCvxMQ2KI1x9pG07foJtCvuhfEOhH6/2+zQKFcTnjTU/wk6Pjjng/Dpa4gvDMaOCXkf8ifPhzvX4/3RBHfHRsMXz6GX0r4hPqGpIe4gxeut64heacfSJiI+c/F2goVG4bF1EK8tKfBR9pgBsJ77fMPwA4scKpwsBfxPxIfkA/uhXEr+JzNymwibiJzYUPEwwNZ2J+KmNPLn66JwKIVH94HF2WuKnLDRCrj7c0BM/uaHz8WMbN0IE7jpPoQG5+u7GjRBkvM5TKDCqH02hnvgZFKYfKGcifloj0+g8o4+fn/gJjMsn/lkV5iC+3sd/46Pz/hF/YZh8/Ish/ll5ePkKcxP/OU+h/4hvNU7nI1BPuA8PGzrWg2cjPi1ujvf3u+c9IJvBR2F7s+svfz7io19jP9Nro5ne1kx82xz+zafh2C/9lIgxiO8azG9/Tfd7qKyJdhLxkWUO/3bRn3zVnof4L/Mt3Lc+xJ/TqhVnkdf56FfPOwwk/rflHT9bs/tUbRp9qBtR4Zk/n4X4QsbWE/JRaCgCPS4P352F+J+Wt3BEXsTXT+S7fElPr2l+4reCwjvbWVhUOBNfl6cnZIJ/aB3uUOqSEHmIuGGDzF5SqGYm5+EvQWFj5aGocA+nX7R59WEK5zEMZFH1srdubrjEVihnG3oSX35LFQcv5roXkH8tZvirivi0Ugi+MSxlG3r6+MVKoebglowG2c+141OxOAYpp+RdPcMCmDOgmvpPJj5oIrtmpZBIZ/H6mvfRE8KT+G/b1cGKmXzalUIQ34ly/KA38QWF92SNbMx7y2esk6ufd7/vbkvADDyyQtCNKUfXeRPfrLBP/KvEh8n+wBRahL9COdswDvHvJOJXqkVtLH39i0/ktxTUfY8diE+kT1yIPwyvc8oAXKFfrEsBxOd1MtTHtzq1Zh7yRW1K73Vm3HmonbomBfHHoXxlgG/uQXzdXzM+8UvqNxs/b+W4Ep9YVEQm/oRe5wxAwet3IX7/D+lVGHx8M/p1xMd8YhevND8f4jPkJvHxlTxEU6siLFXNiYd9tqGMwVTEn+a6z6iQKBcFTET8flEbJ9DrDBfiE/OiP3F9/KFaq8JW0mkciF8CGicWHuogI/MQtXyRb27MFZmLMZwO5CEGxCWiEP/T4+60PT72/8dfQrbHDqqwtN5qFOKftq7r6m3XbbYbaVfgpic+ZIL9KMSvhwGSm378kjQQ2GNbXUJJ/MWUf2mi+muFp+GD25cI8mSJSuJD5/iNQ/xe4WkMcLQXVJCo5mHqefUFhdtuUz/E/fotJa4VDs8QOIYhCvE3L93hYfuSTKKS+KRSefRpiN/1376u2z7ItxlHokT8CgB65378Ffrb3/OtHPp72UTWt5T4p/Ugdijx6e18J6fxrYdOcY+RJH5bz+iLAXGWUOJX1eJOmMQu/iOcJB7QeuAexg7L8/lm7u2X/WWHhwRPcNquhakB5iBC6n78YtnXkuId5duN9x0GZ+6hp1fWCGXbdrvtuLGNamx+/4RHyiMTvzcQ+4Ls27btYxaJDGTNEEhG/GIRjSdNOc+7G904U+beFKjMkHqni/wDDf9Z5+POjAdpb2CvdXg9FTYuzA02KO8IoT4K/Ygfawpc4OA+3l9Abfl+cYg/4HYIpQPm1Y9jcH47n+5B/Gl5mWmt0wxZ96SkwASDteFDfD4LH8q4cqzbmjahxJ+WCMqrMN9KOvOyPd5z3XsY7J4rr9N9iT8xKgfoeVklnw7m4ohPZx56QPgdKGzOQnzsNBduqMGTO7yS9j19/EiT3sMMxGG/SBTIkKuf2aigKYVrI9fovPMZuUbnnVshEPQ5BtN5pPlFIn6V3aPvq/sYzj6Uhzk9+snxjeJkgxW6oza4KRMnjAAjvksUPZZRmgsF3w+A+Gi1cF160I/BA1Ojgsz4Dyf+tCBKNr6zetu6Kl/MfnxT1lgaw2nVnlDi9+MKsit0WrUnmPi4iZOM5xRGqGCT+UOOMRO/meGbL3RfOvTRQ9Bvy9zjcYRsGHSc6j6M+E2kVoVrzCKyQgPxK5clcSPG8J1S/a0Ha4mP0Jgah0LY7WaIiXiws8g4ka8H8cf6GgjWOKF7XLovmWcc128k/ojBpFPgyhj0O90QDtcTf+oJyduUyefjM+SewX83Ls/nh34z8Xl1lMO1L4MaFY1+gICahyFRdE/Q64fXAQ3dWgBKhZT3hAQsIeBouK5L5KBQQXyaaop7C+jDrqNDf5459yygn5gd2mBQoF8mvmfwPMjw7aNfGcooxHpefT6mPCcG+1V7Yl1QRv96Xv0UzLWCnkaKWSjHJ6yIT5j7eQbQx+svkNEfdyUdD1LjsKF8APQLPMRpvGyLvxsdueIFlWsF5VPYBDdlrOhXEL/KCXqAk+6aUri6oEz8bMl4k1sfvb9giX6Dj5/RtY995SX6L7Yff0L/ZfbjL9Gfa5bd8xmZZtk9gzGhPyv9zmL8BQoVPv5lGW/Bx09qvAXipzUulvg6H/8Cjb9A4f8BYQIML+6idNAAAAAASUVORK5CYII=',
                                      ),
                                    ).image,
                                  ),
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 50.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                final selectedMedia =
                                    await selectMediaWithSourceBottomSheet(
                                  context: context,
                                  allowPhoto: true,
                                );
                                if (selectedMedia != null &&
                                    selectedMedia.every((m) =>
                                        validateFileFormat(
                                            m.storagePath, context))) {
                                  setState(
                                      () => _model.isDataUploading2 = true);
                                  var selectedUploadedFiles =
                                      <FFUploadedFile>[];

                                  var downloadUrls = <String>[];
                                  try {
                                    selectedUploadedFiles = selectedMedia
                                        .map((m) => FFUploadedFile(
                                              name:
                                                  m.storagePath.split('/').last,
                                              bytes: m.bytes,
                                              height: m.dimensions?.height,
                                              width: m.dimensions?.width,
                                              blurHash: m.blurHash,
                                            ))
                                        .toList();

                                    downloadUrls = (await Future.wait(
                                      selectedMedia.map(
                                        (m) async => await uploadData(
                                            m.storagePath, m.bytes),
                                      ),
                                    ))
                                        .where((u) => u != null)
                                        .map((u) => u!)
                                        .toList();
                                  } finally {
                                    _model.isDataUploading2 = false;
                                  }
                                  if (selectedUploadedFiles.length ==
                                          selectedMedia.length &&
                                      downloadUrls.length ==
                                          selectedMedia.length) {
                                    setState(() {
                                      _model.uploadedLocalFile2 =
                                          selectedUploadedFiles.first;
                                      _model.uploadedFileUrl2 =
                                          downloadUrls.first;
                                    });
                                  } else {
                                    setState(() {});
                                    return;
                                  }
                                }
                              },
                              child: Container(
                                width: 100.0,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: Image.network(
                                      valueOrDefault<String>(
                                        _model.uploadedFileUrl2,
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX////t7e319fXu7u729vbs7OwAAADr6+vp6enx8fH6+voTExMQEBB5eXn7+/s9PT3Q0NDDw8Pd3d0wMDCGhoa8vLybm5tiYmI4ODhdXV0eHh4mJiYhISF+fn6ioqKLi4tsbGzNzc2zs7MsLCxERESoqKi0tLSWlpbAwMDY2NhTU1NpaWne8zMCAAANN0lEQVR4nO2dC3uUPBOGIQnQsAdb9Wst3dqtrfqq////fWEhQMhpctx2lUt7TZdDeAqbOzOZJAXGuCQF26oLNYp/Ct+9UZRsO1kNM9AFGgUhBKHxBxp+XJQxPEfC9Da9gS7PKIvBwrgapF6cgf8WhU1TDY+1qaqryzKqgv1vTnXO1YUaAg/xG8BXQuI3b+OG0hB/RCTGbwDQiYg/4BGRd45+hORdw3OcEBkd/QRn5TsupV0D8SeAIBybSJTmpB8tpV34ohSqyuLEnxAZGf2koRn5jqtS2qUifhOLuexrkY/vzWhgbCJ+XANjSjPSbygL04w+PissYyOJDjA3E382cAyvv6/asvGdPbpWvWtB/IURjH4yXCObI88aK23/w0r8WKQm1VhxZwI9Hu6Zan38JPDFqa68NjDmCvUe8Pk98ele3c9Ck0Kjjy/T0xf941uaz5EnuDLdqtHH90N/Uzbp+c4N9iBG5xbm48cx6NiUyYDBhsclGgn0CYnf6OGbE/QW4gein8ZoMIAaFdRelpr4C/S7wJcMG3I7K8A4/WuR6Rgd8f3Qn7t3YKAFa/5ao/rxgFZmpejwZzU72ZGJT2m2pgxivtkQs6DGg/XE9wI9+3pnBP34lpYRovoQ9FesEUQsx8Q0RiQ4RvXDPPqs8Ww8tS5sB79XhXDDQnwQ+sU/ZzSsY+2uilJ4o8JCfIjXP22ZPHp+N0D3/6QyMD5PJvjm8egHSGAj6OMTP5tHXxo9+lTEN3vZ0Y3pGcIVOmFdsYtd54302l9MP365Dt3nIH5mA+5kv1eF8EAJlPjv14ASXxO6z+HIh5UFJ76KuV6xdy/QT56nZ+aeK5FGN5cV2sDPIlffH4+PPyjKi1wf4jPnevLo4WeR7/Vp2/5oPRU6/DUDffwSz6AHR/6Lp5pvX1svdjeZiY9Lp7PI53revjp2E0xd89zx9c/cczAodYmCt0uBdX3bupRVTmVRn8QAT4XYRWHVPtXi9rX1KstPoR/xSxePnnyu19ttCz+dPcOhjYZdXPsQ4pPlBnDJC1kgk1iAIS6Wl4P4mE48pPazsPSKDtv3wo34OB/xUTkrBESmW9UT5NVNhmi6B/HR3KYBHKwVeJKYTaEjRhsew3cCvbw5oJ+4tC5y+viKWlSQmD1XP64hgV79XUwe807o42tqUfFFTa8QSnw9anUBf8sryp+i9so4zrBBcFTfFEVX7VKDXiFRg34/vgdF9RkkdKF7hbOvA728qdGP/fgeQnzUJ8TCD7ZWMssXNWU3AYj4vN3koNBBoAb9wzM0hO6jR/UJe3MMzBV3GUEvb2v0szsbO7NyRfWrEldWT7xpoKBXSBQuyJPx3MIIQcRvWKMwJujlTUB/3Ax/kELM08e8Qf/F8NvwFGf0lxQcsY9GfPYVhDjXw3NWvaK7Z+HXqzvVU+ShClBZ1r5+OPGdnGuiBv2u+E/4/VfxRyGx4Ln24D76KMQn1ImwStAfi+JG+OC6KO7lw3r0j9U1e8Ni9f5biY9cBp+hcq94gkygrFAlkVU3DkH0aMTHLqF7VS26I0qFyhd17xO6N6MfQny30P12/QRJo1a4V72orbsjbwk1WHL1G6coOv3R36Uo8XjaRf8nfPixOqXerSRuXur6Od7YQAjxXQef0UO9lrgbdq0VjoUK0Ni8bB7qDwXN6eOXgMy/hUE59GaJx8KocPkUty/bunuYd+UhvtvwOnRbryQei5HdkkJ+1iyx6/of9Q8a5tHDiU9aJJLcbux/1qLEXTFdbEX8luN4/0dQuNl+b/34jnS7dMQnFdV69FrjWy1IPC52KerScdfwFDfb+mWz7Q71f66FehOfegyvu6qXEo/LXQqFfNd9X8kcHg7b/n935VqoN/GxUxbCaBwXKnYEqJDVqKySqQ8P/Z5H4lyot49feiTjlbOIIxLYrXpL+Vkj+g+MNV3IbABq9CuJ7+1ct/hh1PC5ODUY+C4V8aezSLEbP/9C8kT1ccjgs+8f2JO4u+afjNfR8ZB79Nf3Xb19/eZbqCvxMQ2KI1x9pG07foJtCvuhfEOhH6/2+zQKFcTnjTU/wk6Pjjng/Dpa4gvDMaOCXkf8ifPhzvX4/3RBHfHRsMXz6GX0r4hPqGpIe4gxeut64heacfSJiI+c/F2goVG4bF1EK8tKfBR9pgBsJ77fMPwA4scKpwsBfxPxIfkA/uhXEr+JzNymwibiJzYUPEwwNZ2J+KmNPLn66JwKIVH94HF2WuKnLDRCrj7c0BM/uaHz8WMbN0IE7jpPoQG5+u7GjRBkvM5TKDCqH02hnvgZFKYfKGcifloj0+g8o4+fn/gJjMsn/lkV5iC+3sd/46Pz/hF/YZh8/Ish/ll5ePkKcxP/OU+h/4hvNU7nI1BPuA8PGzrWg2cjPi1ujvf3u+c9IJvBR2F7s+svfz7io19jP9Nro5ne1kx82xz+zafh2C/9lIgxiO8azG9/Tfd7qKyJdhLxkWUO/3bRn3zVnof4L/Mt3Lc+xJ/TqhVnkdf56FfPOwwk/rflHT9bs/tUbRp9qBtR4Zk/n4X4QsbWE/JRaCgCPS4P352F+J+Wt3BEXsTXT+S7fElPr2l+4reCwjvbWVhUOBNfl6cnZIJ/aB3uUOqSEHmIuGGDzF5SqGYm5+EvQWFj5aGocA+nX7R59WEK5zEMZFH1srdubrjEVihnG3oSX35LFQcv5roXkH8tZvirivi0Ugi+MSxlG3r6+MVKoebglowG2c+141OxOAYpp+RdPcMCmDOgmvpPJj5oIrtmpZBIZ/H6mvfRE8KT+G/b1cGKmXzalUIQ34ly/KA38QWF92SNbMx7y2esk6ufd7/vbkvADDyyQtCNKUfXeRPfrLBP/KvEh8n+wBRahL9COdswDvHvJOJXqkVtLH39i0/ktxTUfY8diE+kT1yIPwyvc8oAXKFfrEsBxOd1MtTHtzq1Zh7yRW1K73Vm3HmonbomBfHHoXxlgG/uQXzdXzM+8UvqNxs/b+W4Ep9YVEQm/oRe5wxAwet3IX7/D+lVGHx8M/p1xMd8YhevND8f4jPkJvHxlTxEU6siLFXNiYd9tqGMwVTEn+a6z6iQKBcFTET8flEbJ9DrDBfiE/OiP3F9/KFaq8JW0mkciF8CGicWHuogI/MQtXyRb27MFZmLMZwO5CEGxCWiEP/T4+60PT72/8dfQrbHDqqwtN5qFOKftq7r6m3XbbYbaVfgpic+ZIL9KMSvhwGSm378kjQQ2GNbXUJJ/MWUf2mi+muFp+GD25cI8mSJSuJD5/iNQ/xe4WkMcLQXVJCo5mHqefUFhdtuUz/E/fotJa4VDs8QOIYhCvE3L93hYfuSTKKS+KRSefRpiN/1376u2z7ItxlHokT8CgB65378Ffrb3/OtHPp72UTWt5T4p/Ugdijx6e18J6fxrYdOcY+RJH5bz+iLAXGWUOJX1eJOmMQu/iOcJB7QeuAexg7L8/lm7u2X/WWHhwRPcNquhakB5iBC6n78YtnXkuId5duN9x0GZ+6hp1fWCGXbdrvtuLGNamx+/4RHyiMTvzcQ+4Ls27btYxaJDGTNEEhG/GIRjSdNOc+7G904U+beFKjMkHqni/wDDf9Z5+POjAdpb2CvdXg9FTYuzA02KO8IoT4K/Ygfawpc4OA+3l9Abfl+cYg/4HYIpQPm1Y9jcH47n+5B/Gl5mWmt0wxZ96SkwASDteFDfD4LH8q4cqzbmjahxJ+WCMqrMN9KOvOyPd5z3XsY7J4rr9N9iT8xKgfoeVklnw7m4ohPZx56QPgdKGzOQnzsNBduqMGTO7yS9j19/EiT3sMMxGG/SBTIkKuf2aigKYVrI9fovPMZuUbnnVshEPQ5BtN5pPlFIn6V3aPvq/sYzj6Uhzk9+snxjeJkgxW6oza4KRMnjAAjvksUPZZRmgsF3w+A+Gi1cF160I/BA1Ojgsz4Dyf+tCBKNr6zetu6Kl/MfnxT1lgaw2nVnlDi9+MKsit0WrUnmPi4iZOM5xRGqGCT+UOOMRO/meGbL3RfOvTRQ9Bvy9zjcYRsGHSc6j6M+E2kVoVrzCKyQgPxK5clcSPG8J1S/a0Ha4mP0Jgah0LY7WaIiXiws8g4ka8H8cf6GgjWOKF7XLovmWcc128k/ojBpFPgyhj0O90QDtcTf+oJyduUyefjM+SewX83Ls/nh34z8Xl1lMO1L4MaFY1+gICahyFRdE/Q64fXAQ3dWgBKhZT3hAQsIeBouK5L5KBQQXyaaop7C+jDrqNDf5459yygn5gd2mBQoF8mvmfwPMjw7aNfGcooxHpefT6mPCcG+1V7Yl1QRv96Xv0UzLWCnkaKWSjHJ6yIT5j7eQbQx+svkNEfdyUdD1LjsKF8APQLPMRpvGyLvxsdueIFlWsF5VPYBDdlrOhXEL/KCXqAk+6aUri6oEz8bMl4k1sfvb9giX6Dj5/RtY995SX6L7Yff0L/ZfbjL9Gfa5bd8xmZZtk9gzGhPyv9zmL8BQoVPv5lGW/Bx09qvAXipzUulvg6H/8Cjb9A4f8BYQIML+6idNAAAAAASUVORK5CYII=',
                                      ),
                                    ).image,
                                  ),
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                50.0, 0.0, 0.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                final selectedMedia =
                                    await selectMediaWithSourceBottomSheet(
                                  context: context,
                                  allowPhoto: true,
                                );
                                if (selectedMedia != null &&
                                    selectedMedia.every((m) =>
                                        validateFileFormat(
                                            m.storagePath, context))) {
                                  setState(
                                      () => _model.isDataUploading3 = true);
                                  var selectedUploadedFiles =
                                      <FFUploadedFile>[];

                                  var downloadUrls = <String>[];
                                  try {
                                    selectedUploadedFiles = selectedMedia
                                        .map((m) => FFUploadedFile(
                                              name:
                                                  m.storagePath.split('/').last,
                                              bytes: m.bytes,
                                              height: m.dimensions?.height,
                                              width: m.dimensions?.width,
                                              blurHash: m.blurHash,
                                            ))
                                        .toList();

                                    downloadUrls = (await Future.wait(
                                      selectedMedia.map(
                                        (m) async => await uploadData(
                                            m.storagePath, m.bytes),
                                      ),
                                    ))
                                        .where((u) => u != null)
                                        .map((u) => u!)
                                        .toList();
                                  } finally {
                                    _model.isDataUploading3 = false;
                                  }
                                  if (selectedUploadedFiles.length ==
                                          selectedMedia.length &&
                                      downloadUrls.length ==
                                          selectedMedia.length) {
                                    setState(() {
                                      _model.uploadedLocalFile3 =
                                          selectedUploadedFiles.first;
                                      _model.uploadedFileUrl3 =
                                          downloadUrls.first;
                                    });
                                  } else {
                                    setState(() {});
                                    return;
                                  }
                                }
                              },
                              child: Container(
                                width: 100.0,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: Image.network(
                                      valueOrDefault<String>(
                                        _model.uploadedFileUrl3,
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX////t7e319fXu7u729vbs7OwAAADr6+vp6enx8fH6+voTExMQEBB5eXn7+/s9PT3Q0NDDw8Pd3d0wMDCGhoa8vLybm5tiYmI4ODhdXV0eHh4mJiYhISF+fn6ioqKLi4tsbGzNzc2zs7MsLCxERESoqKi0tLSWlpbAwMDY2NhTU1NpaWne8zMCAAANN0lEQVR4nO2dC3uUPBOGIQnQsAdb9Wst3dqtrfqq////fWEhQMhpctx2lUt7TZdDeAqbOzOZJAXGuCQF26oLNYp/Ct+9UZRsO1kNM9AFGgUhBKHxBxp+XJQxPEfC9Da9gS7PKIvBwrgapF6cgf8WhU1TDY+1qaqryzKqgv1vTnXO1YUaAg/xG8BXQuI3b+OG0hB/RCTGbwDQiYg/4BGRd45+hORdw3OcEBkd/QRn5TsupV0D8SeAIBybSJTmpB8tpV34ohSqyuLEnxAZGf2koRn5jqtS2qUifhOLuexrkY/vzWhgbCJ+XANjSjPSbygL04w+PissYyOJDjA3E382cAyvv6/asvGdPbpWvWtB/IURjH4yXCObI88aK23/w0r8WKQm1VhxZwI9Hu6Zan38JPDFqa68NjDmCvUe8Pk98ele3c9Ck0Kjjy/T0xf941uaz5EnuDLdqtHH90N/Uzbp+c4N9iBG5xbm48cx6NiUyYDBhsclGgn0CYnf6OGbE/QW4gein8ZoMIAaFdRelpr4C/S7wJcMG3I7K8A4/WuR6Rgd8f3Qn7t3YKAFa/5ao/rxgFZmpejwZzU72ZGJT2m2pgxivtkQs6DGg/XE9wI9+3pnBP34lpYRovoQ9FesEUQsx8Q0RiQ4RvXDPPqs8Ww8tS5sB79XhXDDQnwQ+sU/ZzSsY+2uilJ4o8JCfIjXP22ZPHp+N0D3/6QyMD5PJvjm8egHSGAj6OMTP5tHXxo9+lTEN3vZ0Y3pGcIVOmFdsYtd54302l9MP365Dt3nIH5mA+5kv1eF8EAJlPjv14ASXxO6z+HIh5UFJ76KuV6xdy/QT56nZ+aeK5FGN5cV2sDPIlffH4+PPyjKi1wf4jPnevLo4WeR7/Vp2/5oPRU6/DUDffwSz6AHR/6Lp5pvX1svdjeZiY9Lp7PI53revjp2E0xd89zx9c/cczAodYmCt0uBdX3bupRVTmVRn8QAT4XYRWHVPtXi9rX1KstPoR/xSxePnnyu19ttCz+dPcOhjYZdXPsQ4pPlBnDJC1kgk1iAIS6Wl4P4mE48pPazsPSKDtv3wo34OB/xUTkrBESmW9UT5NVNhmi6B/HR3KYBHKwVeJKYTaEjRhsew3cCvbw5oJ+4tC5y+viKWlSQmD1XP64hgV79XUwe807o42tqUfFFTa8QSnw9anUBf8sryp+i9so4zrBBcFTfFEVX7VKDXiFRg34/vgdF9RkkdKF7hbOvA728qdGP/fgeQnzUJ8TCD7ZWMssXNWU3AYj4vN3koNBBoAb9wzM0hO6jR/UJe3MMzBV3GUEvb2v0szsbO7NyRfWrEldWT7xpoKBXSBQuyJPx3MIIQcRvWKMwJujlTUB/3Ax/kELM08e8Qf/F8NvwFGf0lxQcsY9GfPYVhDjXw3NWvaK7Z+HXqzvVU+ShClBZ1r5+OPGdnGuiBv2u+E/4/VfxRyGx4Ln24D76KMQn1ImwStAfi+JG+OC6KO7lw3r0j9U1e8Ni9f5biY9cBp+hcq94gkygrFAlkVU3DkH0aMTHLqF7VS26I0qFyhd17xO6N6MfQny30P12/QRJo1a4V72orbsjbwk1WHL1G6coOv3R36Uo8XjaRf8nfPixOqXerSRuXur6Od7YQAjxXQef0UO9lrgbdq0VjoUK0Ni8bB7qDwXN6eOXgMy/hUE59GaJx8KocPkUty/bunuYd+UhvtvwOnRbryQei5HdkkJ+1iyx6/of9Q8a5tHDiU9aJJLcbux/1qLEXTFdbEX8luN4/0dQuNl+b/34jnS7dMQnFdV69FrjWy1IPC52KerScdfwFDfb+mWz7Q71f66FehOfegyvu6qXEo/LXQqFfNd9X8kcHg7b/n935VqoN/GxUxbCaBwXKnYEqJDVqKySqQ8P/Z5H4lyot49feiTjlbOIIxLYrXpL+Vkj+g+MNV3IbABq9CuJ7+1ct/hh1PC5ODUY+C4V8aezSLEbP/9C8kT1ccjgs+8f2JO4u+afjNfR8ZB79Nf3Xb19/eZbqCvxMQ2KI1x9pG07foJtCvuhfEOhH6/2+zQKFcTnjTU/wk6Pjjng/Dpa4gvDMaOCXkf8ifPhzvX4/3RBHfHRsMXz6GX0r4hPqGpIe4gxeut64heacfSJiI+c/F2goVG4bF1EK8tKfBR9pgBsJ77fMPwA4scKpwsBfxPxIfkA/uhXEr+JzNymwibiJzYUPEwwNZ2J+KmNPLn66JwKIVH94HF2WuKnLDRCrj7c0BM/uaHz8WMbN0IE7jpPoQG5+u7GjRBkvM5TKDCqH02hnvgZFKYfKGcifloj0+g8o4+fn/gJjMsn/lkV5iC+3sd/46Pz/hF/YZh8/Ish/ll5ePkKcxP/OU+h/4hvNU7nI1BPuA8PGzrWg2cjPi1ujvf3u+c9IJvBR2F7s+svfz7io19jP9Nro5ne1kx82xz+zafh2C/9lIgxiO8azG9/Tfd7qKyJdhLxkWUO/3bRn3zVnof4L/Mt3Lc+xJ/TqhVnkdf56FfPOwwk/rflHT9bs/tUbRp9qBtR4Zk/n4X4QsbWE/JRaCgCPS4P352F+J+Wt3BEXsTXT+S7fElPr2l+4reCwjvbWVhUOBNfl6cnZIJ/aB3uUOqSEHmIuGGDzF5SqGYm5+EvQWFj5aGocA+nX7R59WEK5zEMZFH1srdubrjEVihnG3oSX35LFQcv5roXkH8tZvirivi0Ugi+MSxlG3r6+MVKoebglowG2c+141OxOAYpp+RdPcMCmDOgmvpPJj5oIrtmpZBIZ/H6mvfRE8KT+G/b1cGKmXzalUIQ34ly/KA38QWF92SNbMx7y2esk6ufd7/vbkvADDyyQtCNKUfXeRPfrLBP/KvEh8n+wBRahL9COdswDvHvJOJXqkVtLH39i0/ktxTUfY8diE+kT1yIPwyvc8oAXKFfrEsBxOd1MtTHtzq1Zh7yRW1K73Vm3HmonbomBfHHoXxlgG/uQXzdXzM+8UvqNxs/b+W4Ep9YVEQm/oRe5wxAwet3IX7/D+lVGHx8M/p1xMd8YhevND8f4jPkJvHxlTxEU6siLFXNiYd9tqGMwVTEn+a6z6iQKBcFTET8flEbJ9DrDBfiE/OiP3F9/KFaq8JW0mkciF8CGicWHuogI/MQtXyRb27MFZmLMZwO5CEGxCWiEP/T4+60PT72/8dfQrbHDqqwtN5qFOKftq7r6m3XbbYbaVfgpic+ZIL9KMSvhwGSm378kjQQ2GNbXUJJ/MWUf2mi+muFp+GD25cI8mSJSuJD5/iNQ/xe4WkMcLQXVJCo5mHqefUFhdtuUz/E/fotJa4VDs8QOIYhCvE3L93hYfuSTKKS+KRSefRpiN/1376u2z7ItxlHokT8CgB65378Ffrb3/OtHPp72UTWt5T4p/Ugdijx6e18J6fxrYdOcY+RJH5bz+iLAXGWUOJX1eJOmMQu/iOcJB7QeuAexg7L8/lm7u2X/WWHhwRPcNquhakB5iBC6n78YtnXkuId5duN9x0GZ+6hp1fWCGXbdrvtuLGNamx+/4RHyiMTvzcQ+4Ls27btYxaJDGTNEEhG/GIRjSdNOc+7G904U+beFKjMkHqni/wDDf9Z5+POjAdpb2CvdXg9FTYuzA02KO8IoT4K/Ygfawpc4OA+3l9Abfl+cYg/4HYIpQPm1Y9jcH47n+5B/Gl5mWmt0wxZ96SkwASDteFDfD4LH8q4cqzbmjahxJ+WCMqrMN9KOvOyPd5z3XsY7J4rr9N9iT8xKgfoeVklnw7m4ohPZx56QPgdKGzOQnzsNBduqMGTO7yS9j19/EiT3sMMxGG/SBTIkKuf2aigKYVrI9fovPMZuUbnnVshEPQ5BtN5pPlFIn6V3aPvq/sYzj6Uhzk9+snxjeJkgxW6oza4KRMnjAAjvksUPZZRmgsF3w+A+Gi1cF160I/BA1Ojgsz4Dyf+tCBKNr6zetu6Kl/MfnxT1lgaw2nVnlDi9+MKsit0WrUnmPi4iZOM5xRGqGCT+UOOMRO/meGbL3RfOvTRQ9Bvy9zjcYRsGHSc6j6M+E2kVoVrzCKyQgPxK5clcSPG8J1S/a0Ha4mP0Jgah0LY7WaIiXiws8g4ka8H8cf6GgjWOKF7XLovmWcc128k/ojBpFPgyhj0O90QDtcTf+oJyduUyefjM+SewX83Ls/nh34z8Xl1lMO1L4MaFY1+gICahyFRdE/Q64fXAQ3dWgBKhZT3hAQsIeBouK5L5KBQQXyaaop7C+jDrqNDf5459yygn5gd2mBQoF8mvmfwPMjw7aNfGcooxHpefT6mPCcG+1V7Yl1QRv96Xv0UzLWCnkaKWSjHJ6yIT5j7eQbQx+svkNEfdyUdD1LjsKF8APQLPMRpvGyLvxsdueIFlWsF5VPYBDdlrOhXEL/KCXqAk+6aUri6oEz8bMl4k1sfvb9giX6Dj5/RtY995SX6L7Yff0L/ZfbjL9Gfa5bd8xmZZtk9gzGhPyv9zmL8BQoVPv5lGW/Bx09qvAXipzUulvg6H/8Cjb9A4f8BYQIML+6idNAAAAAASUVORK5CYII=',
                                      ),
                                    ).image,
                                  ),
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 50.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                final selectedMedia =
                                    await selectMediaWithSourceBottomSheet(
                                  context: context,
                                  allowPhoto: true,
                                );
                                if (selectedMedia != null &&
                                    selectedMedia.every((m) =>
                                        validateFileFormat(
                                            m.storagePath, context))) {
                                  setState(
                                      () => _model.isDataUploading4 = true);
                                  var selectedUploadedFiles =
                                      <FFUploadedFile>[];

                                  var downloadUrls = <String>[];
                                  try {
                                    selectedUploadedFiles = selectedMedia
                                        .map((m) => FFUploadedFile(
                                              name:
                                                  m.storagePath.split('/').last,
                                              bytes: m.bytes,
                                              height: m.dimensions?.height,
                                              width: m.dimensions?.width,
                                              blurHash: m.blurHash,
                                            ))
                                        .toList();

                                    downloadUrls = (await Future.wait(
                                      selectedMedia.map(
                                        (m) async => await uploadData(
                                            m.storagePath, m.bytes),
                                      ),
                                    ))
                                        .where((u) => u != null)
                                        .map((u) => u!)
                                        .toList();
                                  } finally {
                                    _model.isDataUploading4 = false;
                                  }
                                  if (selectedUploadedFiles.length ==
                                          selectedMedia.length &&
                                      downloadUrls.length ==
                                          selectedMedia.length) {
                                    setState(() {
                                      _model.uploadedLocalFile4 =
                                          selectedUploadedFiles.first;
                                      _model.uploadedFileUrl4 =
                                          downloadUrls.first;
                                    });
                                  } else {
                                    setState(() {});
                                    return;
                                  }
                                }
                              },
                              child: Container(
                                width: 100.0,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: Image.network(
                                      valueOrDefault<String>(
                                        _model.uploadedFileUrl4,
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX////t7e319fXu7u729vbs7OwAAADr6+vp6enx8fH6+voTExMQEBB5eXn7+/s9PT3Q0NDDw8Pd3d0wMDCGhoa8vLybm5tiYmI4ODhdXV0eHh4mJiYhISF+fn6ioqKLi4tsbGzNzc2zs7MsLCxERESoqKi0tLSWlpbAwMDY2NhTU1NpaWne8zMCAAANN0lEQVR4nO2dC3uUPBOGIQnQsAdb9Wst3dqtrfqq////fWEhQMhpctx2lUt7TZdDeAqbOzOZJAXGuCQF26oLNYp/Ct+9UZRsO1kNM9AFGgUhBKHxBxp+XJQxPEfC9Da9gS7PKIvBwrgapF6cgf8WhU1TDY+1qaqryzKqgv1vTnXO1YUaAg/xG8BXQuI3b+OG0hB/RCTGbwDQiYg/4BGRd45+hORdw3OcEBkd/QRn5TsupV0D8SeAIBybSJTmpB8tpV34ohSqyuLEnxAZGf2koRn5jqtS2qUifhOLuexrkY/vzWhgbCJ+XANjSjPSbygL04w+PissYyOJDjA3E382cAyvv6/asvGdPbpWvWtB/IURjH4yXCObI88aK23/w0r8WKQm1VhxZwI9Hu6Zan38JPDFqa68NjDmCvUe8Pk98ele3c9Ck0Kjjy/T0xf941uaz5EnuDLdqtHH90N/Uzbp+c4N9iBG5xbm48cx6NiUyYDBhsclGgn0CYnf6OGbE/QW4gein8ZoMIAaFdRelpr4C/S7wJcMG3I7K8A4/WuR6Rgd8f3Qn7t3YKAFa/5ao/rxgFZmpejwZzU72ZGJT2m2pgxivtkQs6DGg/XE9wI9+3pnBP34lpYRovoQ9FesEUQsx8Q0RiQ4RvXDPPqs8Ww8tS5sB79XhXDDQnwQ+sU/ZzSsY+2uilJ4o8JCfIjXP22ZPHp+N0D3/6QyMD5PJvjm8egHSGAj6OMTP5tHXxo9+lTEN3vZ0Y3pGcIVOmFdsYtd54302l9MP365Dt3nIH5mA+5kv1eF8EAJlPjv14ASXxO6z+HIh5UFJ76KuV6xdy/QT56nZ+aeK5FGN5cV2sDPIlffH4+PPyjKi1wf4jPnevLo4WeR7/Vp2/5oPRU6/DUDffwSz6AHR/6Lp5pvX1svdjeZiY9Lp7PI53revjp2E0xd89zx9c/cczAodYmCt0uBdX3bupRVTmVRn8QAT4XYRWHVPtXi9rX1KstPoR/xSxePnnyu19ttCz+dPcOhjYZdXPsQ4pPlBnDJC1kgk1iAIS6Wl4P4mE48pPazsPSKDtv3wo34OB/xUTkrBESmW9UT5NVNhmi6B/HR3KYBHKwVeJKYTaEjRhsew3cCvbw5oJ+4tC5y+viKWlSQmD1XP64hgV79XUwe807o42tqUfFFTa8QSnw9anUBf8sryp+i9so4zrBBcFTfFEVX7VKDXiFRg34/vgdF9RkkdKF7hbOvA728qdGP/fgeQnzUJ8TCD7ZWMssXNWU3AYj4vN3koNBBoAb9wzM0hO6jR/UJe3MMzBV3GUEvb2v0szsbO7NyRfWrEldWT7xpoKBXSBQuyJPx3MIIQcRvWKMwJujlTUB/3Ax/kELM08e8Qf/F8NvwFGf0lxQcsY9GfPYVhDjXw3NWvaK7Z+HXqzvVU+ShClBZ1r5+OPGdnGuiBv2u+E/4/VfxRyGx4Ln24D76KMQn1ImwStAfi+JG+OC6KO7lw3r0j9U1e8Ni9f5biY9cBp+hcq94gkygrFAlkVU3DkH0aMTHLqF7VS26I0qFyhd17xO6N6MfQny30P12/QRJo1a4V72orbsjbwk1WHL1G6coOv3R36Uo8XjaRf8nfPixOqXerSRuXur6Od7YQAjxXQef0UO9lrgbdq0VjoUK0Ni8bB7qDwXN6eOXgMy/hUE59GaJx8KocPkUty/bunuYd+UhvtvwOnRbryQei5HdkkJ+1iyx6/of9Q8a5tHDiU9aJJLcbux/1qLEXTFdbEX8luN4/0dQuNl+b/34jnS7dMQnFdV69FrjWy1IPC52KerScdfwFDfb+mWz7Q71f66FehOfegyvu6qXEo/LXQqFfNd9X8kcHg7b/n935VqoN/GxUxbCaBwXKnYEqJDVqKySqQ8P/Z5H4lyot49feiTjlbOIIxLYrXpL+Vkj+g+MNV3IbABq9CuJ7+1ct/hh1PC5ODUY+C4V8aezSLEbP/9C8kT1ccjgs+8f2JO4u+afjNfR8ZB79Nf3Xb19/eZbqCvxMQ2KI1x9pG07foJtCvuhfEOhH6/2+zQKFcTnjTU/wk6Pjjng/Dpa4gvDMaOCXkf8ifPhzvX4/3RBHfHRsMXz6GX0r4hPqGpIe4gxeut64heacfSJiI+c/F2goVG4bF1EK8tKfBR9pgBsJ77fMPwA4scKpwsBfxPxIfkA/uhXEr+JzNymwibiJzYUPEwwNZ2J+KmNPLn66JwKIVH94HF2WuKnLDRCrj7c0BM/uaHz8WMbN0IE7jpPoQG5+u7GjRBkvM5TKDCqH02hnvgZFKYfKGcifloj0+g8o4+fn/gJjMsn/lkV5iC+3sd/46Pz/hF/YZh8/Ish/ll5ePkKcxP/OU+h/4hvNU7nI1BPuA8PGzrWg2cjPi1ujvf3u+c9IJvBR2F7s+svfz7io19jP9Nro5ne1kx82xz+zafh2C/9lIgxiO8azG9/Tfd7qKyJdhLxkWUO/3bRn3zVnof4L/Mt3Lc+xJ/TqhVnkdf56FfPOwwk/rflHT9bs/tUbRp9qBtR4Zk/n4X4QsbWE/JRaCgCPS4P352F+J+Wt3BEXsTXT+S7fElPr2l+4reCwjvbWVhUOBNfl6cnZIJ/aB3uUOqSEHmIuGGDzF5SqGYm5+EvQWFj5aGocA+nX7R59WEK5zEMZFH1srdubrjEVihnG3oSX35LFQcv5roXkH8tZvirivi0Ugi+MSxlG3r6+MVKoebglowG2c+141OxOAYpp+RdPcMCmDOgmvpPJj5oIrtmpZBIZ/H6mvfRE8KT+G/b1cGKmXzalUIQ34ly/KA38QWF92SNbMx7y2esk6ufd7/vbkvADDyyQtCNKUfXeRPfrLBP/KvEh8n+wBRahL9COdswDvHvJOJXqkVtLH39i0/ktxTUfY8diE+kT1yIPwyvc8oAXKFfrEsBxOd1MtTHtzq1Zh7yRW1K73Vm3HmonbomBfHHoXxlgG/uQXzdXzM+8UvqNxs/b+W4Ep9YVEQm/oRe5wxAwet3IX7/D+lVGHx8M/p1xMd8YhevND8f4jPkJvHxlTxEU6siLFXNiYd9tqGMwVTEn+a6z6iQKBcFTET8flEbJ9DrDBfiE/OiP3F9/KFaq8JW0mkciF8CGicWHuogI/MQtXyRb27MFZmLMZwO5CEGxCWiEP/T4+60PT72/8dfQrbHDqqwtN5qFOKftq7r6m3XbbYbaVfgpic+ZIL9KMSvhwGSm378kjQQ2GNbXUJJ/MWUf2mi+muFp+GD25cI8mSJSuJD5/iNQ/xe4WkMcLQXVJCo5mHqefUFhdtuUz/E/fotJa4VDs8QOIYhCvE3L93hYfuSTKKS+KRSefRpiN/1376u2z7ItxlHokT8CgB65378Ffrb3/OtHPp72UTWt5T4p/Ugdijx6e18J6fxrYdOcY+RJH5bz+iLAXGWUOJX1eJOmMQu/iOcJB7QeuAexg7L8/lm7u2X/WWHhwRPcNquhakB5iBC6n78YtnXkuId5duN9x0GZ+6hp1fWCGXbdrvtuLGNamx+/4RHyiMTvzcQ+4Ls27btYxaJDGTNEEhG/GIRjSdNOc+7G904U+beFKjMkHqni/wDDf9Z5+POjAdpb2CvdXg9FTYuzA02KO8IoT4K/Ygfawpc4OA+3l9Abfl+cYg/4HYIpQPm1Y9jcH47n+5B/Gl5mWmt0wxZ96SkwASDteFDfD4LH8q4cqzbmjahxJ+WCMqrMN9KOvOyPd5z3XsY7J4rr9N9iT8xKgfoeVklnw7m4ohPZx56QPgdKGzOQnzsNBduqMGTO7yS9j19/EiT3sMMxGG/SBTIkKuf2aigKYVrI9fovPMZuUbnnVshEPQ5BtN5pPlFIn6V3aPvq/sYzj6Uhzk9+snxjeJkgxW6oza4KRMnjAAjvksUPZZRmgsF3w+A+Gi1cF160I/BA1Ojgsz4Dyf+tCBKNr6zetu6Kl/MfnxT1lgaw2nVnlDi9+MKsit0WrUnmPi4iZOM5xRGqGCT+UOOMRO/meGbL3RfOvTRQ9Bvy9zjcYRsGHSc6j6M+E2kVoVrzCKyQgPxK5clcSPG8J1S/a0Ha4mP0Jgah0LY7WaIiXiws8g4ka8H8cf6GgjWOKF7XLovmWcc128k/ojBpFPgyhj0O90QDtcTf+oJyduUyefjM+SewX83Ls/nh34z8Xl1lMO1L4MaFY1+gICahyFRdE/Q64fXAQ3dWgBKhZT3hAQsIeBouK5L5KBQQXyaaop7C+jDrqNDf5459yygn5gd2mBQoF8mvmfwPMjw7aNfGcooxHpefT6mPCcG+1V7Yl1QRv96Xv0UzLWCnkaKWSjHJ6yIT5j7eQbQx+svkNEfdyUdD1LjsKF8APQLPMRpvGyLvxsdueIFlWsF5VPYBDdlrOhXEL/KCXqAk+6aUri6oEz8bMl4k1sfvb9giX6Dj5/RtY995SX6L7Yff0L/ZfbjL9Gfa5bd8xmZZtk9gzGhPyv9zmL8BQoVPv5lGW/Bx09qvAXipzUulvg6H/8Cjb9A4f8BYQIML+6idNAAAAAASUVORK5CYII=',
                                      ),
                                    ).image,
                                  ),
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 8.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                50.0, 0.0, 0.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                final selectedMedia =
                                    await selectMediaWithSourceBottomSheet(
                                  context: context,
                                  allowPhoto: true,
                                );
                                if (selectedMedia != null &&
                                    selectedMedia.every((m) =>
                                        validateFileFormat(
                                            m.storagePath, context))) {
                                  setState(
                                      () => _model.isDataUploading5 = true);
                                  var selectedUploadedFiles =
                                      <FFUploadedFile>[];

                                  var downloadUrls = <String>[];
                                  try {
                                    selectedUploadedFiles = selectedMedia
                                        .map((m) => FFUploadedFile(
                                              name:
                                                  m.storagePath.split('/').last,
                                              bytes: m.bytes,
                                              height: m.dimensions?.height,
                                              width: m.dimensions?.width,
                                              blurHash: m.blurHash,
                                            ))
                                        .toList();

                                    downloadUrls = (await Future.wait(
                                      selectedMedia.map(
                                        (m) async => await uploadData(
                                            m.storagePath, m.bytes),
                                      ),
                                    ))
                                        .where((u) => u != null)
                                        .map((u) => u!)
                                        .toList();
                                  } finally {
                                    _model.isDataUploading5 = false;
                                  }
                                  if (selectedUploadedFiles.length ==
                                          selectedMedia.length &&
                                      downloadUrls.length ==
                                          selectedMedia.length) {
                                    setState(() {
                                      _model.uploadedLocalFile5 =
                                          selectedUploadedFiles.first;
                                      _model.uploadedFileUrl5 =
                                          downloadUrls.first;
                                    });
                                  } else {
                                    setState(() {});
                                    return;
                                  }
                                }
                              },
                              child: Container(
                                width: 100.0,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: Image.network(
                                      valueOrDefault<String>(
                                        _model.uploadedFileUrl5,
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX////t7e319fXu7u729vbs7OwAAADr6+vp6enx8fH6+voTExMQEBB5eXn7+/s9PT3Q0NDDw8Pd3d0wMDCGhoa8vLybm5tiYmI4ODhdXV0eHh4mJiYhISF+fn6ioqKLi4tsbGzNzc2zs7MsLCxERESoqKi0tLSWlpbAwMDY2NhTU1NpaWne8zMCAAANN0lEQVR4nO2dC3uUPBOGIQnQsAdb9Wst3dqtrfqq////fWEhQMhpctx2lUt7TZdDeAqbOzOZJAXGuCQF26oLNYp/Ct+9UZRsO1kNM9AFGgUhBKHxBxp+XJQxPEfC9Da9gS7PKIvBwrgapF6cgf8WhU1TDY+1qaqryzKqgv1vTnXO1YUaAg/xG8BXQuI3b+OG0hB/RCTGbwDQiYg/4BGRd45+hORdw3OcEBkd/QRn5TsupV0D8SeAIBybSJTmpB8tpV34ohSqyuLEnxAZGf2koRn5jqtS2qUifhOLuexrkY/vzWhgbCJ+XANjSjPSbygL04w+PissYyOJDjA3E382cAyvv6/asvGdPbpWvWtB/IURjH4yXCObI88aK23/w0r8WKQm1VhxZwI9Hu6Zan38JPDFqa68NjDmCvUe8Pk98ele3c9Ck0Kjjy/T0xf941uaz5EnuDLdqtHH90N/Uzbp+c4N9iBG5xbm48cx6NiUyYDBhsclGgn0CYnf6OGbE/QW4gein8ZoMIAaFdRelpr4C/S7wJcMG3I7K8A4/WuR6Rgd8f3Qn7t3YKAFa/5ao/rxgFZmpejwZzU72ZGJT2m2pgxivtkQs6DGg/XE9wI9+3pnBP34lpYRovoQ9FesEUQsx8Q0RiQ4RvXDPPqs8Ww8tS5sB79XhXDDQnwQ+sU/ZzSsY+2uilJ4o8JCfIjXP22ZPHp+N0D3/6QyMD5PJvjm8egHSGAj6OMTP5tHXxo9+lTEN3vZ0Y3pGcIVOmFdsYtd54302l9MP365Dt3nIH5mA+5kv1eF8EAJlPjv14ASXxO6z+HIh5UFJ76KuV6xdy/QT56nZ+aeK5FGN5cV2sDPIlffH4+PPyjKi1wf4jPnevLo4WeR7/Vp2/5oPRU6/DUDffwSz6AHR/6Lp5pvX1svdjeZiY9Lp7PI53revjp2E0xd89zx9c/cczAodYmCt0uBdX3bupRVTmVRn8QAT4XYRWHVPtXi9rX1KstPoR/xSxePnnyu19ttCz+dPcOhjYZdXPsQ4pPlBnDJC1kgk1iAIS6Wl4P4mE48pPazsPSKDtv3wo34OB/xUTkrBESmW9UT5NVNhmi6B/HR3KYBHKwVeJKYTaEjRhsew3cCvbw5oJ+4tC5y+viKWlSQmD1XP64hgV79XUwe807o42tqUfFFTa8QSnw9anUBf8sryp+i9so4zrBBcFTfFEVX7VKDXiFRg34/vgdF9RkkdKF7hbOvA728qdGP/fgeQnzUJ8TCD7ZWMssXNWU3AYj4vN3koNBBoAb9wzM0hO6jR/UJe3MMzBV3GUEvb2v0szsbO7NyRfWrEldWT7xpoKBXSBQuyJPx3MIIQcRvWKMwJujlTUB/3Ax/kELM08e8Qf/F8NvwFGf0lxQcsY9GfPYVhDjXw3NWvaK7Z+HXqzvVU+ShClBZ1r5+OPGdnGuiBv2u+E/4/VfxRyGx4Ln24D76KMQn1ImwStAfi+JG+OC6KO7lw3r0j9U1e8Ni9f5biY9cBp+hcq94gkygrFAlkVU3DkH0aMTHLqF7VS26I0qFyhd17xO6N6MfQny30P12/QRJo1a4V72orbsjbwk1WHL1G6coOv3R36Uo8XjaRf8nfPixOqXerSRuXur6Od7YQAjxXQef0UO9lrgbdq0VjoUK0Ni8bB7qDwXN6eOXgMy/hUE59GaJx8KocPkUty/bunuYd+UhvtvwOnRbryQei5HdkkJ+1iyx6/of9Q8a5tHDiU9aJJLcbux/1qLEXTFdbEX8luN4/0dQuNl+b/34jnS7dMQnFdV69FrjWy1IPC52KerScdfwFDfb+mWz7Q71f66FehOfegyvu6qXEo/LXQqFfNd9X8kcHg7b/n935VqoN/GxUxbCaBwXKnYEqJDVqKySqQ8P/Z5H4lyot49feiTjlbOIIxLYrXpL+Vkj+g+MNV3IbABq9CuJ7+1ct/hh1PC5ODUY+C4V8aezSLEbP/9C8kT1ccjgs+8f2JO4u+afjNfR8ZB79Nf3Xb19/eZbqCvxMQ2KI1x9pG07foJtCvuhfEOhH6/2+zQKFcTnjTU/wk6Pjjng/Dpa4gvDMaOCXkf8ifPhzvX4/3RBHfHRsMXz6GX0r4hPqGpIe4gxeut64heacfSJiI+c/F2goVG4bF1EK8tKfBR9pgBsJ77fMPwA4scKpwsBfxPxIfkA/uhXEr+JzNymwibiJzYUPEwwNZ2J+KmNPLn66JwKIVH94HF2WuKnLDRCrj7c0BM/uaHz8WMbN0IE7jpPoQG5+u7GjRBkvM5TKDCqH02hnvgZFKYfKGcifloj0+g8o4+fn/gJjMsn/lkV5iC+3sd/46Pz/hF/YZh8/Ish/ll5ePkKcxP/OU+h/4hvNU7nI1BPuA8PGzrWg2cjPi1ujvf3u+c9IJvBR2F7s+svfz7io19jP9Nro5ne1kx82xz+zafh2C/9lIgxiO8azG9/Tfd7qKyJdhLxkWUO/3bRn3zVnof4L/Mt3Lc+xJ/TqhVnkdf56FfPOwwk/rflHT9bs/tUbRp9qBtR4Zk/n4X4QsbWE/JRaCgCPS4P352F+J+Wt3BEXsTXT+S7fElPr2l+4reCwjvbWVhUOBNfl6cnZIJ/aB3uUOqSEHmIuGGDzF5SqGYm5+EvQWFj5aGocA+nX7R59WEK5zEMZFH1srdubrjEVihnG3oSX35LFQcv5roXkH8tZvirivi0Ugi+MSxlG3r6+MVKoebglowG2c+141OxOAYpp+RdPcMCmDOgmvpPJj5oIrtmpZBIZ/H6mvfRE8KT+G/b1cGKmXzalUIQ34ly/KA38QWF92SNbMx7y2esk6ufd7/vbkvADDyyQtCNKUfXeRPfrLBP/KvEh8n+wBRahL9COdswDvHvJOJXqkVtLH39i0/ktxTUfY8diE+kT1yIPwyvc8oAXKFfrEsBxOd1MtTHtzq1Zh7yRW1K73Vm3HmonbomBfHHoXxlgG/uQXzdXzM+8UvqNxs/b+W4Ep9YVEQm/oRe5wxAwet3IX7/D+lVGHx8M/p1xMd8YhevND8f4jPkJvHxlTxEU6siLFXNiYd9tqGMwVTEn+a6z6iQKBcFTET8flEbJ9DrDBfiE/OiP3F9/KFaq8JW0mkciF8CGicWHuogI/MQtXyRb27MFZmLMZwO5CEGxCWiEP/T4+60PT72/8dfQrbHDqqwtN5qFOKftq7r6m3XbbYbaVfgpic+ZIL9KMSvhwGSm378kjQQ2GNbXUJJ/MWUf2mi+muFp+GD25cI8mSJSuJD5/iNQ/xe4WkMcLQXVJCo5mHqefUFhdtuUz/E/fotJa4VDs8QOIYhCvE3L93hYfuSTKKS+KRSefRpiN/1376u2z7ItxlHokT8CgB65378Ffrb3/OtHPp72UTWt5T4p/Ugdijx6e18J6fxrYdOcY+RJH5bz+iLAXGWUOJX1eJOmMQu/iOcJB7QeuAexg7L8/lm7u2X/WWHhwRPcNquhakB5iBC6n78YtnXkuId5duN9x0GZ+6hp1fWCGXbdrvtuLGNamx+/4RHyiMTvzcQ+4Ls27btYxaJDGTNEEhG/GIRjSdNOc+7G904U+beFKjMkHqni/wDDf9Z5+POjAdpb2CvdXg9FTYuzA02KO8IoT4K/Ygfawpc4OA+3l9Abfl+cYg/4HYIpQPm1Y9jcH47n+5B/Gl5mWmt0wxZ96SkwASDteFDfD4LH8q4cqzbmjahxJ+WCMqrMN9KOvOyPd5z3XsY7J4rr9N9iT8xKgfoeVklnw7m4ohPZx56QPgdKGzOQnzsNBduqMGTO7yS9j19/EiT3sMMxGG/SBTIkKuf2aigKYVrI9fovPMZuUbnnVshEPQ5BtN5pPlFIn6V3aPvq/sYzj6Uhzk9+snxjeJkgxW6oza4KRMnjAAjvksUPZZRmgsF3w+A+Gi1cF160I/BA1Ojgsz4Dyf+tCBKNr6zetu6Kl/MfnxT1lgaw2nVnlDi9+MKsit0WrUnmPi4iZOM5xRGqGCT+UOOMRO/meGbL3RfOvTRQ9Bvy9zjcYRsGHSc6j6M+E2kVoVrzCKyQgPxK5clcSPG8J1S/a0Ha4mP0Jgah0LY7WaIiXiws8g4ka8H8cf6GgjWOKF7XLovmWcc128k/ojBpFPgyhj0O90QDtcTf+oJyduUyefjM+SewX83Ls/nh34z8Xl1lMO1L4MaFY1+gICahyFRdE/Q64fXAQ3dWgBKhZT3hAQsIeBouK5L5KBQQXyaaop7C+jDrqNDf5459yygn5gd2mBQoF8mvmfwPMjw7aNfGcooxHpefT6mPCcG+1V7Yl1QRv96Xv0UzLWCnkaKWSjHJ6yIT5j7eQbQx+svkNEfdyUdD1LjsKF8APQLPMRpvGyLvxsdueIFlWsF5VPYBDdlrOhXEL/KCXqAk+6aUri6oEz8bMl4k1sfvb9giX6Dj5/RtY995SX6L7Yff0L/ZfbjL9Gfa5bd8xmZZtk9gzGhPyv9zmL8BQoVPv5lGW/Bx09qvAXipzUulvg6H/8Cjb9A4f8BYQIML+6idNAAAAAASUVORK5CYII=',
                                      ),
                                    ).image,
                                  ),
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsetsDirectional.fromSTEB(
                                0.0, 0.0, 50.0, 0.0),
                            child: InkWell(
                              splashColor: Colors.transparent,
                              focusColor: Colors.transparent,
                              hoverColor: Colors.transparent,
                              highlightColor: Colors.transparent,
                              onTap: () async {
                                final selectedMedia =
                                    await selectMediaWithSourceBottomSheet(
                                  context: context,
                                  allowPhoto: true,
                                );
                                if (selectedMedia != null &&
                                    selectedMedia.every((m) =>
                                        validateFileFormat(
                                            m.storagePath, context))) {
                                  setState(
                                      () => _model.isDataUploading6 = true);
                                  var selectedUploadedFiles =
                                      <FFUploadedFile>[];

                                  var downloadUrls = <String>[];
                                  try {
                                    selectedUploadedFiles = selectedMedia
                                        .map((m) => FFUploadedFile(
                                              name:
                                                  m.storagePath.split('/').last,
                                              bytes: m.bytes,
                                              height: m.dimensions?.height,
                                              width: m.dimensions?.width,
                                              blurHash: m.blurHash,
                                            ))
                                        .toList();

                                    downloadUrls = (await Future.wait(
                                      selectedMedia.map(
                                        (m) async => await uploadData(
                                            m.storagePath, m.bytes),
                                      ),
                                    ))
                                        .where((u) => u != null)
                                        .map((u) => u!)
                                        .toList();
                                  } finally {
                                    _model.isDataUploading6 = false;
                                  }
                                  if (selectedUploadedFiles.length ==
                                          selectedMedia.length &&
                                      downloadUrls.length ==
                                          selectedMedia.length) {
                                    setState(() {
                                      _model.uploadedLocalFile6 =
                                          selectedUploadedFiles.first;
                                      _model.uploadedFileUrl6 =
                                          downloadUrls.first;
                                    });
                                  } else {
                                    setState(() {});
                                    return;
                                  }
                                }
                              },
                              child: Container(
                                width: 100.0,
                                height: 100.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .secondaryBackground,
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: Image.network(
                                      valueOrDefault<String>(
                                        _model.uploadedFileUrl6,
                                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX////t7e319fXu7u729vbs7OwAAADr6+vp6enx8fH6+voTExMQEBB5eXn7+/s9PT3Q0NDDw8Pd3d0wMDCGhoa8vLybm5tiYmI4ODhdXV0eHh4mJiYhISF+fn6ioqKLi4tsbGzNzc2zs7MsLCxERESoqKi0tLSWlpbAwMDY2NhTU1NpaWne8zMCAAANN0lEQVR4nO2dC3uUPBOGIQnQsAdb9Wst3dqtrfqq////fWEhQMhpctx2lUt7TZdDeAqbOzOZJAXGuCQF26oLNYp/Ct+9UZRsO1kNM9AFGgUhBKHxBxp+XJQxPEfC9Da9gS7PKIvBwrgapF6cgf8WhU1TDY+1qaqryzKqgv1vTnXO1YUaAg/xG8BXQuI3b+OG0hB/RCTGbwDQiYg/4BGRd45+hORdw3OcEBkd/QRn5TsupV0D8SeAIBybSJTmpB8tpV34ohSqyuLEnxAZGf2koRn5jqtS2qUifhOLuexrkY/vzWhgbCJ+XANjSjPSbygL04w+PissYyOJDjA3E382cAyvv6/asvGdPbpWvWtB/IURjH4yXCObI88aK23/w0r8WKQm1VhxZwI9Hu6Zan38JPDFqa68NjDmCvUe8Pk98ele3c9Ck0Kjjy/T0xf941uaz5EnuDLdqtHH90N/Uzbp+c4N9iBG5xbm48cx6NiUyYDBhsclGgn0CYnf6OGbE/QW4gein8ZoMIAaFdRelpr4C/S7wJcMG3I7K8A4/WuR6Rgd8f3Qn7t3YKAFa/5ao/rxgFZmpejwZzU72ZGJT2m2pgxivtkQs6DGg/XE9wI9+3pnBP34lpYRovoQ9FesEUQsx8Q0RiQ4RvXDPPqs8Ww8tS5sB79XhXDDQnwQ+sU/ZzSsY+2uilJ4o8JCfIjXP22ZPHp+N0D3/6QyMD5PJvjm8egHSGAj6OMTP5tHXxo9+lTEN3vZ0Y3pGcIVOmFdsYtd54302l9MP365Dt3nIH5mA+5kv1eF8EAJlPjv14ASXxO6z+HIh5UFJ76KuV6xdy/QT56nZ+aeK5FGN5cV2sDPIlffH4+PPyjKi1wf4jPnevLo4WeR7/Vp2/5oPRU6/DUDffwSz6AHR/6Lp5pvX1svdjeZiY9Lp7PI53revjp2E0xd89zx9c/cczAodYmCt0uBdX3bupRVTmVRn8QAT4XYRWHVPtXi9rX1KstPoR/xSxePnnyu19ttCz+dPcOhjYZdXPsQ4pPlBnDJC1kgk1iAIS6Wl4P4mE48pPazsPSKDtv3wo34OB/xUTkrBESmW9UT5NVNhmi6B/HR3KYBHKwVeJKYTaEjRhsew3cCvbw5oJ+4tC5y+viKWlSQmD1XP64hgV79XUwe807o42tqUfFFTa8QSnw9anUBf8sryp+i9so4zrBBcFTfFEVX7VKDXiFRg34/vgdF9RkkdKF7hbOvA728qdGP/fgeQnzUJ8TCD7ZWMssXNWU3AYj4vN3koNBBoAb9wzM0hO6jR/UJe3MMzBV3GUEvb2v0szsbO7NyRfWrEldWT7xpoKBXSBQuyJPx3MIIQcRvWKMwJujlTUB/3Ax/kELM08e8Qf/F8NvwFGf0lxQcsY9GfPYVhDjXw3NWvaK7Z+HXqzvVU+ShClBZ1r5+OPGdnGuiBv2u+E/4/VfxRyGx4Ln24D76KMQn1ImwStAfi+JG+OC6KO7lw3r0j9U1e8Ni9f5biY9cBp+hcq94gkygrFAlkVU3DkH0aMTHLqF7VS26I0qFyhd17xO6N6MfQny30P12/QRJo1a4V72orbsjbwk1WHL1G6coOv3R36Uo8XjaRf8nfPixOqXerSRuXur6Od7YQAjxXQef0UO9lrgbdq0VjoUK0Ni8bB7qDwXN6eOXgMy/hUE59GaJx8KocPkUty/bunuYd+UhvtvwOnRbryQei5HdkkJ+1iyx6/of9Q8a5tHDiU9aJJLcbux/1qLEXTFdbEX8luN4/0dQuNl+b/34jnS7dMQnFdV69FrjWy1IPC52KerScdfwFDfb+mWz7Q71f66FehOfegyvu6qXEo/LXQqFfNd9X8kcHg7b/n935VqoN/GxUxbCaBwXKnYEqJDVqKySqQ8P/Z5H4lyot49feiTjlbOIIxLYrXpL+Vkj+g+MNV3IbABq9CuJ7+1ct/hh1PC5ODUY+C4V8aezSLEbP/9C8kT1ccjgs+8f2JO4u+afjNfR8ZB79Nf3Xb19/eZbqCvxMQ2KI1x9pG07foJtCvuhfEOhH6/2+zQKFcTnjTU/wk6Pjjng/Dpa4gvDMaOCXkf8ifPhzvX4/3RBHfHRsMXz6GX0r4hPqGpIe4gxeut64heacfSJiI+c/F2goVG4bF1EK8tKfBR9pgBsJ77fMPwA4scKpwsBfxPxIfkA/uhXEr+JzNymwibiJzYUPEwwNZ2J+KmNPLn66JwKIVH94HF2WuKnLDRCrj7c0BM/uaHz8WMbN0IE7jpPoQG5+u7GjRBkvM5TKDCqH02hnvgZFKYfKGcifloj0+g8o4+fn/gJjMsn/lkV5iC+3sd/46Pz/hF/YZh8/Ish/ll5ePkKcxP/OU+h/4hvNU7nI1BPuA8PGzrWg2cjPi1ujvf3u+c9IJvBR2F7s+svfz7io19jP9Nro5ne1kx82xz+zafh2C/9lIgxiO8azG9/Tfd7qKyJdhLxkWUO/3bRn3zVnof4L/Mt3Lc+xJ/TqhVnkdf56FfPOwwk/rflHT9bs/tUbRp9qBtR4Zk/n4X4QsbWE/JRaCgCPS4P352F+J+Wt3BEXsTXT+S7fElPr2l+4reCwjvbWVhUOBNfl6cnZIJ/aB3uUOqSEHmIuGGDzF5SqGYm5+EvQWFj5aGocA+nX7R59WEK5zEMZFH1srdubrjEVihnG3oSX35LFQcv5roXkH8tZvirivi0Ugi+MSxlG3r6+MVKoebglowG2c+141OxOAYpp+RdPcMCmDOgmvpPJj5oIrtmpZBIZ/H6mvfRE8KT+G/b1cGKmXzalUIQ34ly/KA38QWF92SNbMx7y2esk6ufd7/vbkvADDyyQtCNKUfXeRPfrLBP/KvEh8n+wBRahL9COdswDvHvJOJXqkVtLH39i0/ktxTUfY8diE+kT1yIPwyvc8oAXKFfrEsBxOd1MtTHtzq1Zh7yRW1K73Vm3HmonbomBfHHoXxlgG/uQXzdXzM+8UvqNxs/b+W4Ep9YVEQm/oRe5wxAwet3IX7/D+lVGHx8M/p1xMd8YhevND8f4jPkJvHxlTxEU6siLFXNiYd9tqGMwVTEn+a6z6iQKBcFTET8flEbJ9DrDBfiE/OiP3F9/KFaq8JW0mkciF8CGicWHuogI/MQtXyRb27MFZmLMZwO5CEGxCWiEP/T4+60PT72/8dfQrbHDqqwtN5qFOKftq7r6m3XbbYbaVfgpic+ZIL9KMSvhwGSm378kjQQ2GNbXUJJ/MWUf2mi+muFp+GD25cI8mSJSuJD5/iNQ/xe4WkMcLQXVJCo5mHqefUFhdtuUz/E/fotJa4VDs8QOIYhCvE3L93hYfuSTKKS+KRSefRpiN/1376u2z7ItxlHokT8CgB65378Ffrb3/OtHPp72UTWt5T4p/Ugdijx6e18J6fxrYdOcY+RJH5bz+iLAXGWUOJX1eJOmMQu/iOcJB7QeuAexg7L8/lm7u2X/WWHhwRPcNquhakB5iBC6n78YtnXkuId5duN9x0GZ+6hp1fWCGXbdrvtuLGNamx+/4RHyiMTvzcQ+4Ls27btYxaJDGTNEEhG/GIRjSdNOc+7G904U+beFKjMkHqni/wDDf9Z5+POjAdpb2CvdXg9FTYuzA02KO8IoT4K/Ygfawpc4OA+3l9Abfl+cYg/4HYIpQPm1Y9jcH47n+5B/Gl5mWmt0wxZ96SkwASDteFDfD4LH8q4cqzbmjahxJ+WCMqrMN9KOvOyPd5z3XsY7J4rr9N9iT8xKgfoeVklnw7m4ohPZx56QPgdKGzOQnzsNBduqMGTO7yS9j19/EiT3sMMxGG/SBTIkKuf2aigKYVrI9fovPMZuUbnnVshEPQ5BtN5pPlFIn6V3aPvq/sYzj6Uhzk9+snxjeJkgxW6oza4KRMnjAAjvksUPZZRmgsF3w+A+Gi1cF160I/BA1Ojgsz4Dyf+tCBKNr6zetu6Kl/MfnxT1lgaw2nVnlDi9+MKsit0WrUnmPi4iZOM5xRGqGCT+UOOMRO/meGbL3RfOvTRQ9Bvy9zjcYRsGHSc6j6M+E2kVoVrzCKyQgPxK5clcSPG8J1S/a0Ha4mP0Jgah0LY7WaIiXiws8g4ka8H8cf6GgjWOKF7XLovmWcc128k/ojBpFPgyhj0O90QDtcTf+oJyduUyefjM+SewX83Ls/nh34z8Xl1lMO1L4MaFY1+gICahyFRdE/Q64fXAQ3dWgBKhZT3hAQsIeBouK5L5KBQQXyaaop7C+jDrqNDf5459yygn5gd2mBQoF8mvmfwPMjw7aNfGcooxHpefT6mPCcG+1V7Yl1QRv96Xv0UzLWCnkaKWSjHJ6yIT5j7eQbQx+svkNEfdyUdD1LjsKF8APQLPMRpvGyLvxsdueIFlWsF5VPYBDdlrOhXEL/KCXqAk+6aUri6oEz8bMl4k1sfvb9giX6Dj5/RtY995SX6L7Yff0L/ZfbjL9Gfa5bd8xmZZtk9gzGhPyv9zmL8BQoVPv5lGW/Bx09qvAXipzUulvg6H/8Cjb9A4f8BYQIML+6idNAAAAAASUVORK5CYII=',
                                      ),
                                    ).image,
                                  ),
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0.0, 8.0, 0.0, 0.0),
                  child: StreamBuilder<List<FormsRecord>>(
                    stream: queryFormsRecord(),
                    builder: (context, snapshot) {
                      // Customize what your widget looks like when it's loading.
                      if (!snapshot.hasData) {
                        return Center(
                          child: SizedBox(
                            width: 50.0,
                            height: 50.0,
                            child: CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(
                                FlutterFlowTheme.of(context).primary,
                              ),
                            ),
                          ),
                        );
                      }
                      List<FormsRecord> buttonFormsRecordList = snapshot.data!;
                      return FFButtonWidget(
                        onPressed: () async {
                          await FormsRecord.collection.doc().set({
                            ...createFormsRecordData(
                              skuName: _model.sKUNameController.text,
                              category: _model.dropDownValue1,
                              subcat: _model.dropDownValue2,
                              length:
                                  double.tryParse(_model.lenController.text),
                              width:
                                  double.tryParse(_model.widthController.text),
                              height:
                                  double.tryParse(_model.heightController.text),
                              quantity:
                                  int.tryParse(_model.quantityController.text),
                              cost: double.tryParse(_model.costController.text),
                              comment: _model.commentsController.text,
                              userid: currentUserReference,
                              img1: _model.uploadedFileUrl1,
                              img2: _model.uploadedFileUrl2,
                              img3: _model.uploadedFileUrl3,
                              img4: _model.uploadedFileUrl4,
                              img5: _model.uploadedFileUrl6,
                              img6: _model.uploadedFileUrl6,
                              edittime: getCurrentTimestamp,
                              skuId: buttonFormsRecordList.length.toString(),
                            ),
                            'createdtime': FieldValue.serverTimestamp(),
                          });

                          context.pushNamed('UserHome');
                        },
                        text: 'Submit',
                        options: FFButtonOptions(
                          height: 40.0,
                          padding: EdgeInsetsDirectional.fromSTEB(
                              24.0, 0.0, 24.0, 0.0),
                          iconPadding: EdgeInsetsDirectional.fromSTEB(
                              0.0, 0.0, 0.0, 0.0),
                          color: FlutterFlowTheme.of(context).primary,
                          textStyle:
                              FlutterFlowTheme.of(context).titleSmall.override(
                                    fontFamily: 'Readex Pro',
                                    color: Colors.white,
                                  ),
                          elevation: 3.0,
                          borderSide: BorderSide(
                            color: Colors.transparent,
                            width: 1.0,
                          ),
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
