import '/category/addcategory/addcategory_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'categoryerror_model.dart';
export 'categoryerror_model.dart';

class CategoryerrorWidget extends StatefulWidget {
  const CategoryerrorWidget({Key? key}) : super(key: key);

  @override
  _CategoryerrorWidgetState createState() => _CategoryerrorWidgetState();
}

class _CategoryerrorWidgetState extends State<CategoryerrorWidget> {
  late CategoryerrorModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => CategoryerrorModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(12.0, 12.0, 12.0, 12.0),
      child: Container(
        width: 350.0,
        height: 50.0,
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.max,
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            FlutterFlowIconButton(
              borderColor: Color(0x00FFFFFF),
              borderRadius: 20.0,
              borderWidth: 1.0,
              buttonSize: 40.0,
              fillColor: Color(0x00FFFFFF),
              icon: Icon(
                Icons.arrow_back_rounded,
                color: Color(0xD1EF3939),
                size: 24.0,
              ),
              onPressed: () async {
                await showModalBottomSheet(
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  enableDrag: false,
                  context: context,
                  builder: (context) {
                    return Padding(
                      padding: MediaQuery.viewInsetsOf(context),
                      child: AddcategoryWidget(),
                    );
                  },
                ).then((value) => setState(() {}));
              },
            ),
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(8.0, 12.0, 8.0, 8.0),
              child: Text(
                'Category name already in use',
                style: FlutterFlowTheme.of(context).bodyMedium.override(
                      fontFamily: 'Readex Pro',
                      color: Color(0xD1EF3939),
                    ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
