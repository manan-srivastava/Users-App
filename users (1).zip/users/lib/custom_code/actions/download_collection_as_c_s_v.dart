// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert' show utf8;
import 'package:download/download.dart';

Future downloadCollectionAsCSV(List<FormsRecord>? docs) async {
  docs = docs ?? [];

  // Add the company name and address as a header
  String companyName = "Your Company Name";
  String companyAddress = "Your Company Address";
  String header = "$companyName,$companyAddress\n\n";

  String fileContent = header +
      "sku_name, sku_id,createdtime, edittime, category, subcat, vendor, length, width, height, quantity, cost, comment, img1, img2, img3, img4, img5, img6";

  docs.asMap().forEach((index, record) => fileContent = fileContent +
      "\n" +
      record.skuName.toString() +
      "," +
      record.skuId.toString() +
      "," +
      record.createdtime.toString() +
      "," +
      record.edittime.toString() +
      "," +
      record.category.toString() +
      "," +
      record.subcat.toString() +
      "," +
      record.vendor.toString() +
      "," +
      record.length.toString() +
      "," +
      record.width.toString() +
      "," +
      record.height.toString() +
      "," +
      record.quantity.toString() +
      "," +
      record.cost.toString() +
      "," +
      record.comment.toString() +
      "," +
      record.img1.toString() +
      "," +
      record.img2.toString() +
      "," +
      record.img3.toString() +
      "," +
      record.img4.toString() +
      "," +
      record.img5.toString() +
      "," +
      record.img6.toString());

  // Example of date formating thanks to Edmund Ong
  // DateFormat('dd-MM-yyyy').format(record.attendanceDate!) +
  //     "," +
  //     DateFormat('HH:mm').format(record.timeIn!) +
  //     "," +

  final fileName = "FF" + DateTime.now().toString() + ".csv";

  // Encode the string as a List<int> of UTF-8 bytes
  var bytes = utf8.encode(fileContent);

  final stream = Stream.fromIterable(bytes);
  return download(stream, fileName);
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the button on the right!
