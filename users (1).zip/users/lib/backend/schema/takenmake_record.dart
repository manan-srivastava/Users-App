import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TakenmakeRecord extends FirestoreRecord {
  TakenmakeRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "makename" field.
  List<String>? _makename;
  List<String> get makename => _makename ?? const [];
  bool hasMakename() => _makename != null;

  void _initializeFields() {
    _makename = getDataList(snapshotData['makename']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('takenmake');

  static Stream<TakenmakeRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TakenmakeRecord.fromSnapshot(s));

  static Future<TakenmakeRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TakenmakeRecord.fromSnapshot(s));

  static TakenmakeRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TakenmakeRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TakenmakeRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TakenmakeRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TakenmakeRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TakenmakeRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTakenmakeRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class TakenmakeRecordDocumentEquality implements Equality<TakenmakeRecord> {
  const TakenmakeRecordDocumentEquality();

  @override
  bool equals(TakenmakeRecord? e1, TakenmakeRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.makename, e2?.makename);
  }

  @override
  int hash(TakenmakeRecord? e) => const ListEquality().hash([e?.makename]);

  @override
  bool isValidKey(Object? o) => o is TakenmakeRecord;
}
