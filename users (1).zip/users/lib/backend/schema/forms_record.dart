import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class FormsRecord extends FirestoreRecord {
  FormsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "sku_name" field.
  String? _skuName;
  String get skuName => _skuName ?? '';
  bool hasSkuName() => _skuName != null;

  // "vendor" field.
  String? _vendor;
  String get vendor => _vendor ?? '';
  bool hasVendor() => _vendor != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  bool hasCategory() => _category != null;

  // "subcat" field.
  String? _subcat;
  String get subcat => _subcat ?? '';
  bool hasSubcat() => _subcat != null;

  // "length" field.
  double? _length;
  double get length => _length ?? 0.0;
  bool hasLength() => _length != null;

  // "width" field.
  double? _width;
  double get width => _width ?? 0.0;
  bool hasWidth() => _width != null;

  // "height" field.
  double? _height;
  double get height => _height ?? 0.0;
  bool hasHeight() => _height != null;

  // "quantity" field.
  int? _quantity;
  int get quantity => _quantity ?? 0;
  bool hasQuantity() => _quantity != null;

  // "cost" field.
  double? _cost;
  double get cost => _cost ?? 0.0;
  bool hasCost() => _cost != null;

  // "comment" field.
  String? _comment;
  String get comment => _comment ?? '';
  bool hasComment() => _comment != null;

  // "userid" field.
  DocumentReference? _userid;
  DocumentReference? get userid => _userid;
  bool hasUserid() => _userid != null;

  // "createdtime" field.
  DateTime? _createdtime;
  DateTime? get createdtime => _createdtime;
  bool hasCreatedtime() => _createdtime != null;

  // "img1" field.
  String? _img1;
  String get img1 => _img1 ?? '';
  bool hasImg1() => _img1 != null;

  // "img2" field.
  String? _img2;
  String get img2 => _img2 ?? '';
  bool hasImg2() => _img2 != null;

  // "img3" field.
  String? _img3;
  String get img3 => _img3 ?? '';
  bool hasImg3() => _img3 != null;

  // "img4" field.
  String? _img4;
  String get img4 => _img4 ?? '';
  bool hasImg4() => _img4 != null;

  // "img5" field.
  String? _img5;
  String get img5 => _img5 ?? '';
  bool hasImg5() => _img5 != null;

  // "img6" field.
  String? _img6;
  String get img6 => _img6 ?? '';
  bool hasImg6() => _img6 != null;

  // "edittime" field.
  DateTime? _edittime;
  DateTime? get edittime => _edittime;
  bool hasEdittime() => _edittime != null;

  // "sku_id" field.
  String? _skuId;
  String get skuId => _skuId ?? '';
  bool hasSkuId() => _skuId != null;

  void _initializeFields() {
    _skuName = snapshotData['sku_name'] as String?;
    _vendor = snapshotData['vendor'] as String?;
    _category = snapshotData['category'] as String?;
    _subcat = snapshotData['subcat'] as String?;
    _length = castToType<double>(snapshotData['length']);
    _width = castToType<double>(snapshotData['width']);
    _height = castToType<double>(snapshotData['height']);
    _quantity = castToType<int>(snapshotData['quantity']);
    _cost = castToType<double>(snapshotData['cost']);
    _comment = snapshotData['comment'] as String?;
    _userid = snapshotData['userid'] as DocumentReference?;
    _createdtime = snapshotData['createdtime'] as DateTime?;
    _img1 = snapshotData['img1'] as String?;
    _img2 = snapshotData['img2'] as String?;
    _img3 = snapshotData['img3'] as String?;
    _img4 = snapshotData['img4'] as String?;
    _img5 = snapshotData['img5'] as String?;
    _img6 = snapshotData['img6'] as String?;
    _edittime = snapshotData['edittime'] as DateTime?;
    _skuId = snapshotData['sku_id'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Forms');

  static Stream<FormsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => FormsRecord.fromSnapshot(s));

  static Future<FormsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => FormsRecord.fromSnapshot(s));

  static FormsRecord fromSnapshot(DocumentSnapshot snapshot) => FormsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static FormsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      FormsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'FormsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is FormsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createFormsRecordData({
  String? skuName,
  String? vendor,
  String? category,
  String? subcat,
  double? length,
  double? width,
  double? height,
  int? quantity,
  double? cost,
  String? comment,
  DocumentReference? userid,
  DateTime? createdtime,
  String? img1,
  String? img2,
  String? img3,
  String? img4,
  String? img5,
  String? img6,
  DateTime? edittime,
  String? skuId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'sku_name': skuName,
      'vendor': vendor,
      'category': category,
      'subcat': subcat,
      'length': length,
      'width': width,
      'height': height,
      'quantity': quantity,
      'cost': cost,
      'comment': comment,
      'userid': userid,
      'createdtime': createdtime,
      'img1': img1,
      'img2': img2,
      'img3': img3,
      'img4': img4,
      'img5': img5,
      'img6': img6,
      'edittime': edittime,
      'sku_id': skuId,
    }.withoutNulls,
  );

  return firestoreData;
}

class FormsRecordDocumentEquality implements Equality<FormsRecord> {
  const FormsRecordDocumentEquality();

  @override
  bool equals(FormsRecord? e1, FormsRecord? e2) {
    return e1?.skuName == e2?.skuName &&
        e1?.vendor == e2?.vendor &&
        e1?.category == e2?.category &&
        e1?.subcat == e2?.subcat &&
        e1?.length == e2?.length &&
        e1?.width == e2?.width &&
        e1?.height == e2?.height &&
        e1?.quantity == e2?.quantity &&
        e1?.cost == e2?.cost &&
        e1?.comment == e2?.comment &&
        e1?.userid == e2?.userid &&
        e1?.createdtime == e2?.createdtime &&
        e1?.img1 == e2?.img1 &&
        e1?.img2 == e2?.img2 &&
        e1?.img3 == e2?.img3 &&
        e1?.img4 == e2?.img4 &&
        e1?.img5 == e2?.img5 &&
        e1?.img6 == e2?.img6 &&
        e1?.edittime == e2?.edittime &&
        e1?.skuId == e2?.skuId;
  }

  @override
  int hash(FormsRecord? e) => const ListEquality().hash([
        e?.skuName,
        e?.vendor,
        e?.category,
        e?.subcat,
        e?.length,
        e?.width,
        e?.height,
        e?.quantity,
        e?.cost,
        e?.comment,
        e?.userid,
        e?.createdtime,
        e?.img1,
        e?.img2,
        e?.img3,
        e?.img4,
        e?.img5,
        e?.img6,
        e?.edittime,
        e?.skuId
      ]);

  @override
  bool isValidKey(Object? o) => o is FormsRecord;
}
