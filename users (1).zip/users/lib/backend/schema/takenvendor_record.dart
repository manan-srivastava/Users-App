import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TakenvendorRecord extends FirestoreRecord {
  TakenvendorRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "makevendor" field.
  List<String>? _makevendor;
  List<String> get makevendor => _makevendor ?? const [];
  bool hasMakevendor() => _makevendor != null;

  void _initializeFields() {
    _makevendor = getDataList(snapshotData['makevendor']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('takenvendor');

  static Stream<TakenvendorRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TakenvendorRecord.fromSnapshot(s));

  static Future<TakenvendorRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TakenvendorRecord.fromSnapshot(s));

  static TakenvendorRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TakenvendorRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TakenvendorRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TakenvendorRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TakenvendorRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TakenvendorRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTakenvendorRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class TakenvendorRecordDocumentEquality implements Equality<TakenvendorRecord> {
  const TakenvendorRecordDocumentEquality();

  @override
  bool equals(TakenvendorRecord? e1, TakenvendorRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.makevendor, e2?.makevendor);
  }

  @override
  int hash(TakenvendorRecord? e) => const ListEquality().hash([e?.makevendor]);

  @override
  bool isValidKey(Object? o) => o is TakenvendorRecord;
}
