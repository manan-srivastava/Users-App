import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TakencategoryRecord extends FirestoreRecord {
  TakencategoryRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "categoryname" field.
  List<String>? _categoryname;
  List<String> get categoryname => _categoryname ?? const [];
  bool hasCategoryname() => _categoryname != null;

  void _initializeFields() {
    _categoryname = getDataList(snapshotData['categoryname']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('takencategory');

  static Stream<TakencategoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TakencategoryRecord.fromSnapshot(s));

  static Future<TakencategoryRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TakencategoryRecord.fromSnapshot(s));

  static TakencategoryRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TakencategoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TakencategoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TakencategoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TakencategoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TakencategoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTakencategoryRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class TakencategoryRecordDocumentEquality
    implements Equality<TakencategoryRecord> {
  const TakencategoryRecordDocumentEquality();

  @override
  bool equals(TakencategoryRecord? e1, TakencategoryRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.categoryname, e2?.categoryname);
  }

  @override
  int hash(TakencategoryRecord? e) =>
      const ListEquality().hash([e?.categoryname]);

  @override
  bool isValidKey(Object? o) => o is TakencategoryRecord;
}
