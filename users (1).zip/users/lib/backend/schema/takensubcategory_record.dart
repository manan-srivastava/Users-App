import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TakensubcategoryRecord extends FirestoreRecord {
  TakensubcategoryRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "subcatname" field.
  List<String>? _subcatname;
  List<String> get subcatname => _subcatname ?? const [];
  bool hasSubcatname() => _subcatname != null;

  void _initializeFields() {
    _subcatname = getDataList(snapshotData['subcatname']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('takensubcategory');

  static Stream<TakensubcategoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TakensubcategoryRecord.fromSnapshot(s));

  static Future<TakensubcategoryRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => TakensubcategoryRecord.fromSnapshot(s));

  static TakensubcategoryRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TakensubcategoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TakensubcategoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TakensubcategoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TakensubcategoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TakensubcategoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTakensubcategoryRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class TakensubcategoryRecordDocumentEquality
    implements Equality<TakensubcategoryRecord> {
  const TakensubcategoryRecordDocumentEquality();

  @override
  bool equals(TakensubcategoryRecord? e1, TakensubcategoryRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.subcatname, e2?.subcatname);
  }

  @override
  int hash(TakensubcategoryRecord? e) =>
      const ListEquality().hash([e?.subcatname]);

  @override
  bool isValidKey(Object? o) => o is TakensubcategoryRecord;
}
