import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VendorRecord extends FirestoreRecord {
  VendorRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "company_name" field.
  String? _companyName;
  String get companyName => _companyName ?? '';
  bool hasCompanyName() => _companyName != null;

  // "contact_person" field.
  String? _contactPerson;
  String get contactPerson => _contactPerson ?? '';
  bool hasContactPerson() => _contactPerson != null;

  // "ph_number" field.
  String? _phNumber;
  String get phNumber => _phNumber ?? '';
  bool hasPhNumber() => _phNumber != null;

  // "mail" field.
  String? _mail;
  String get mail => _mail ?? '';
  bool hasMail() => _mail != null;

  // "address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  void _initializeFields() {
    _companyName = snapshotData['company_name'] as String?;
    _contactPerson = snapshotData['contact_person'] as String?;
    _phNumber = snapshotData['ph_number'] as String?;
    _mail = snapshotData['mail'] as String?;
    _address = snapshotData['address'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('vendor');

  static Stream<VendorRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VendorRecord.fromSnapshot(s));

  static Future<VendorRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VendorRecord.fromSnapshot(s));

  static VendorRecord fromSnapshot(DocumentSnapshot snapshot) => VendorRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VendorRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VendorRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VendorRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VendorRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVendorRecordData({
  String? companyName,
  String? contactPerson,
  String? phNumber,
  String? mail,
  String? address,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'company_name': companyName,
      'contact_person': contactPerson,
      'ph_number': phNumber,
      'mail': mail,
      'address': address,
    }.withoutNulls,
  );

  return firestoreData;
}

class VendorRecordDocumentEquality implements Equality<VendorRecord> {
  const VendorRecordDocumentEquality();

  @override
  bool equals(VendorRecord? e1, VendorRecord? e2) {
    return e1?.companyName == e2?.companyName &&
        e1?.contactPerson == e2?.contactPerson &&
        e1?.phNumber == e2?.phNumber &&
        e1?.mail == e2?.mail &&
        e1?.address == e2?.address;
  }

  @override
  int hash(VendorRecord? e) => const ListEquality().hash(
      [e?.companyName, e?.contactPerson, e?.phNumber, e?.mail, e?.address]);

  @override
  bool isValidKey(Object? o) => o is VendorRecord;
}
