import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class TakenstageRecord extends FirestoreRecord {
  TakenstageRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "stagename" field.
  List<String>? _stagename;
  List<String> get stagename => _stagename ?? const [];
  bool hasStagename() => _stagename != null;

  void _initializeFields() {
    _stagename = getDataList(snapshotData['stagename']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('takenstage');

  static Stream<TakenstageRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => TakenstageRecord.fromSnapshot(s));

  static Future<TakenstageRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => TakenstageRecord.fromSnapshot(s));

  static TakenstageRecord fromSnapshot(DocumentSnapshot snapshot) =>
      TakenstageRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static TakenstageRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      TakenstageRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'TakenstageRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is TakenstageRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createTakenstageRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class TakenstageRecordDocumentEquality implements Equality<TakenstageRecord> {
  const TakenstageRecordDocumentEquality();

  @override
  bool equals(TakenstageRecord? e1, TakenstageRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.stagename, e2?.stagename);
  }

  @override
  int hash(TakenstageRecord? e) => const ListEquality().hash([e?.stagename]);

  @override
  bool isValidKey(Object? o) => o is TakenstageRecord;
}
