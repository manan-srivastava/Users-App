import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyApdmxOxgKAfJWfqEWE_3oFuiPy8FiBWO4",
            authDomain: "appdara-73b9c.firebaseapp.com",
            projectId: "appdara-73b9c",
            storageBucket: "appdara-73b9c.appspot.com",
            messagingSenderId: "801767835347",
            appId: "1:801767835347:web:190abbcfed84c8b6047626",
            measurementId: "G-VGW33N9QFF"));
  } else {
    await Firebase.initializeApp();
  }
}
